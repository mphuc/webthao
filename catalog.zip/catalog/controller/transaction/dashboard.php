<?php
class ControllerTransactionDashboard extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/transaction/dashboard.js');
			$self -> document -> addScript('catalog/view/javascript/jquery.marquee.js');
			// $self -> document -> addScript('catalog/view/javascript/countdown/jquery.countdown.min.js');
			$self -> load -> model('simple_blog/article');
		};

		//!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		//$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		
		

		
		$data['self'] = $this;
		
		// getArticles
		$page = isset($this->request->get['page']) ? $this->request->get['page'] : 1;      

		$limit = 15;
		$start = (($page - 1) * 15) + 1;
		$buy_total = $this-> model_transaction_customer ->sumGDtransaction()-1;
		$pagination = new Pagination();
		$pagination->total = $buy_total;
		$pagination->page = $page;
		$pagination->limit = $limit; 
		$pagination->num_links = 5;
		//$pagination->text = 'text';
		$pagination->url = $this->url->link('transaction/dashboard', 'page={page}', 'SSL');
		$data['buy'] = array();
		$data['buy'] = $this -> model_transaction_customer -> getGDtransaction($limit,$start);
		
		$data['pagination_buy'] = $pagination->render();

		
		$pages = isset($this -> request -> get['pages']) ? $this -> request -> get['pages'] : 1;
		$starts = (($pages - 1) * 15)+1;
		$sell_total = $this-> model_transaction_customer ->sumPDtransaction()-1;
		$pagination_sell = new Pagination();
		$pagination_sell->total = $sell_total;
		$pagination_sell->page = $pages;
		$pagination_sell->limit = $limit; 
		$pagination_sell->num_links = 5;
		//$pagination->text = 'text';
		$pagination_sell->url = $this->url->link('transaction/dashboard', 'pages={page}', 'SSL');
		$data['sell'] = array();
		$data['sell'] = $this -> model_transaction_customer -> getPDtransaction($limit,$starts);
		
		$data['pagination_sell'] = $pagination_sell->render();
		$data['url_sell'] = $this->url->link('transaction/sell');
		$data['url_buy'] = $this->url->link('transaction/buy');
		$data['show_massage'] = $this -> model_transaction_customer -> show_massage();

		$data['get_tranferlist_all'] = $this -> model_transaction_customer -> get_tranferlist_all();

		$data['getGDtransaction_max'] = $this -> model_transaction_customer -> getGDtransaction_max();
		$data['getPDtransaction_min'] = $this -> model_transaction_customer -> getPDtransaction_min();
		$data['getCustomer_buyid'] = $this -> model_transaction_customer -> getCustomer_buyid($this->session->data['customer_id']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/dashboard.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/dashboard.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	public function update_gd(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$amountcm = array_key_exists('amountcm', $this -> request -> post) ? $this -> request -> post['amountcm'] : "Error";
			$price = array_key_exists('price', $this -> request -> post) ? $this -> request -> post['price'] : "Error";
			$amountbtc = array_key_exists('amountbtc', $this -> request -> post) ? $this -> request -> post['amountbtc'] : "Error";
			if ($amountcm == "Error" || $price == "Error" || $amountbtc == "Error" ) {
				$json['error'] = -1;
				
			}
			$amountcm = doubleval(str_replace(",","",$amountcm));
			$price = doubleval(str_replace(",","",$price));
			$this -> load -> model('transaction/customer');
			$data['get_gd_create'] = $this -> model_transaction_customer -> get_gd_create($this->request->post['token']);
			count($data['get_gd_create']) == 0 && $json['error'] = -1;
			/**/
			$amount_coinmax = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
			if (floatval($amount_coinmax) >= $amountcm )
			{
				$this ->model_transaction_customer->update_gd_buy_gd_number($amountcm,$price,$amountbtc*100000000,$this->request->post['token']);
				$json['complate'] = 1;
				
			}
			else{
				$json['btc'] = -1;
			}
			$this->response->setOutput(json_encode($json));
		}
	}
	public function get_username($customer_id){
		
		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> get_username_all($customer_id);
	}
	public function update_pd(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$amountcm = array_key_exists('amountcm', $this -> request -> post) ? $this -> request -> post['amountcm'] : "Error";
			$price = array_key_exists('price', $this -> request -> post) ? $this -> request -> post['price'] : "Error";
			$amountbtc = array_key_exists('amountbtc', $this -> request -> post) ? $this -> request -> post['amountbtc'] : "Error";
			if ($amountcm == "Error" || $price == "Error" || $amountbtc == "Error" ) {
				$json['error'] = -1;
				
			}
			$amountcm = doubleval(str_replace(",","",$amountcm));
			$price = doubleval(str_replace(",","",$price));
			$this -> load -> model('transaction/customer');
			$data['get_gd_create'] = $this -> model_transaction_customer -> get_pd_create($this->request->post['token']);
			count($data['get_gd_create']) == 0 && $json['error'] = -1;
			$amount_coinmax = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
			$block_io = new BlockIo(key, pin, block_version);
			$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio();

			$balnce = $block_io->get_address_balance(array('labels' => $get_wallet_blockio['label']));
			$balnce = $balnce->data->available_balance;
			if ($balnce >= $amountbtc )
			{
				$this ->model_transaction_customer->update_pd_buy_pd_number($amountcm,$price,$amountbtc*100000000,$this->request->post['token']);
				$json['complate'] = 1;
				
			}
			else{
				$json['btc'] = -1;
			}
			$this->response->setOutput(json_encode($json));
		}
	}

	public function message(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$message = array_key_exists('message', $this -> request -> post) ? $this -> request -> post['message'] : "Error";
			if ($message == "Error") {
				$json['error'] = -1;
			}
			$this -> load -> model('transaction/customer');
			$last_id = $this -> model_transaction_customer -> insermessage($this->session->data['customer_id'],$message);
			$get_message_byid = $this-> model_transaction_customer -> get_message_byid($last_id);
			$json['message'] = json_encode($get_message_byid);
			$this->response->setOutput(json_encode($json));
		}
	}

	public function show_massage(){

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$this -> load -> model('transaction/customer');
		$show_massage = $this -> model_transaction_customer -> show_massage();

		$show_massage = json_encode($show_massage);
		$this->response->setOutput(json_encode($show_massage));
	}

	public function RequestPDFinish(){
		$this->load->model('account/customer');
		$gds = $this -> model_account_customer -> getAllPD(7, 0, 2);
		$html = '';
		
		foreach ($gds as $key => $value) {
			$html .= '<p class="list-group-item"><span class="badge">'.($value['filled']/100000000).' BTC</span>'.$value['username'].'</p>';
		}
		

		$json['html'] = $html;
		$html = null;
		$this -> response -> setOutput(json_encode($json));
	}
	public function viewBlogs(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/dashboard/dashboard.js');
			$self -> load -> model('simple_blog/article');
		};
		

		//language
		$this -> load -> model('account/customer');
		$getLanguage = $this -> model_account_customer -> getLanguage($this -> session -> data['customer_id']);
		$data['language']= $getLanguage;
		$language = new Language($getLanguage);
		$language -> load('account/dashboard');
		
		$data['lang'] = $language -> data;

		//method to call function
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect($this -> url -> link('/login.html'));
		call_user_func_array("myConfig", array($this));

		//data render website
		//start load country model

		if ($this -> request -> server['HTTPS']) {
			$server = $this -> config -> get('config_ssl');
		} else {
			$server = $this -> config -> get('config_url');
		}

		$data['base'] = $server;
		$data['self'] = $this;
			//method to call function

			!$this -> request -> get['token']  && $this -> response -> redirect($this -> url -> link('account/dashboard', '', 'SSL'));
			$id_ = $this -> request -> get['token'];

if ($getLanguage == 'vietnamese') {
			$Language_id = 2;
		}else{
			$Language_id = 1;
		}
			$this->load->model('simple_blog/article');
			$data['detail_articles'] = $this->model_simple_blog_article->getArticlesBlogs($id_, $Language_id);        	
		
			if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/account/showblog.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/account/showblog.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/showblog.tpl', $data));
		}
		}

	public function changeLange(){
		if ($this -> customer -> isLogged() && $this -> session -> data['customer_id']) {
			$this -> load -> model('account/customer');
			$json['success'] = $this -> model_account_customer -> updateLanguage( $this -> session -> data['customer_id'], $this -> request -> get['lang'] ) ;
			$this -> response -> setOutput(json_encode($json));
		}
	}

	/*
	 *
	 * ajax count total tree member
	 */
	public function totaltree() {
		if ($this -> customer -> isLogged() && $this -> session -> data['customer_id']) {
			$this -> load -> model('account/customer');
			$json['success'] = intval($this -> model_account_customer -> getCountTreeCustom($this -> session -> data['customer_id']));
			$this -> response -> setOutput(json_encode($json));
		}
	}
	public function total_binary_left($customer_id){
		$this -> load -> model('account/customer');

		$count = $this -> model_account_customer ->  getCustomer_ML($customer_id);
		if(intval($count['left']) === 0){
			return 0;
		}else{
			$count = $this -> model_account_customer -> getCountBinaryTreeCustom($count['left']);
			$count = (intval($count) + 1);
			return $count;
		}

		

	}

	public function total_binary_right($customer_id){
		$this -> load -> model('account/customer');

		$count = $this -> model_account_customer ->  getCustomer_ML($customer_id);
		if(intval($count['right']) === 0){
			return 0;
		}else{
			$count = $this -> model_account_customer -> getCountBinaryTreeCustom($count['right']);
			$count = (intval($count) + 1);
			return  $count;
		}


	}


	public function total_pd_left($customer_id){
		$this -> load -> model('account/customer');
		$count = $this -> model_account_customer ->  getCustomer($customer_id);
		if(intval($count['total_pd_left']) === 0){
			return 0;
		}else{
			return $count['total_pd_left'] / 100000000;
		}

	}
	public function total_pd_right(){
		$this -> load -> model('account/customer');
		$count = $this -> model_account_customer ->  getCustomer($this -> session -> data['customer_id']);

		if(intval($count['total_pd_right']) === 0){
			return 0;
		}else{
			return round($count['total_pd_right'] / 100000000,8);

		}
		$this -> response -> setOutput(json_encode($json));
	}
	public function totalpin() {
		if ($this -> customer -> isLogged() && $this -> session -> data['customer_id']) {
			$this -> load -> model('account/customer');
			$pin = $this -> model_account_customer -> getCustomer($this -> session -> data['customer_id']);
			$pin = $pin['ping'];
			$json['success'] = intval($pin);
			$pin = null;
			$this -> response -> setOutput(json_encode($json));
		}
	}

	public function analytics() {

		if ($this -> customer -> isLogged() && $this -> session -> data['customer_id']) {
			$this -> load -> model('account/customer');
			$json['success'] = intval($this -> model_account_customer -> getCountLevelCustom($this -> session -> data['customer_id'], $this -> request -> get['level']));
			$this -> response -> setOutput(json_encode($json));
		}
	}

	public function countPD($customer_id){
		
		$this -> load -> model('account/customer');

		$total = $this -> model_account_customer -> getTotalPD($customer_id);
		$total = $total['number'];
		return intval($total)/100000000;
		
	}


	public function countGD(){
		if ($this -> customer -> isLogged() && $this -> session -> data['customer_id']) {
			$this -> load -> model('account/customer');
			$total = $this -> model_account_customer -> getTotalGD($this -> session -> data['customer_id']);
			$total = $total['number'];
			$json['success'] = intval($total);
			$total = null;
			$this -> response -> setOutput(json_encode($json));
		}
	}

	public function getR_Wallet_payment($customer_id){

		$this -> load -> model('account/customer');
		// $checkR_Wallet = $this -> model_account_customer -> checkR_Wallet($customer_id);
		// if(intval($checkR_Wallet['number'])  === 0){
		// 	if(!$this -> model_account_customer -> insertR_Wallet($customer_id)){
		// 		die();
		// 	}
		// }
	
		/*$getRwallet = $this -> model_account_customer -> getR_Wallet($customer_id);
		$getGDRecived = $this -> model_account_customer -> getTotalGD($customer_id);*/

		$total = $this -> model_account_customer -> getR_Wallet_payment($customer_id);
		//print_r($total); die;
		$total = count($total) > 0 ? $total['amount'] : 0;
		$json['success'] = $total;
		return round(($json['success']/100000000),8);
		

	}

	public function getCWallet($customer_id){

		$this -> load -> model('account/customer');

		$checkC_Wallet = $this -> model_account_customer -> checkC_Wallet($customer_id);


		if(intval($checkC_Wallet['number'])  === 0){
			if(!$this -> model_account_customer -> insertC_Wallet($customer_id)){
				die();
			}
		}
		$total = $this -> model_account_customer -> getC_Wallet($customer_id);
		$total = count($total) > 0 ? $total['amount'] : 0;
		
		$json['success'] = $total;
		$total = null;
		return round(($json['success']/100000000),8);
		
		
	}
	public function getCNWallet($customer_id){
		$this -> load -> model('account/customer');
		$getCustomer = $this -> model_account_customer -> getCustomer($this->session->data['customer_id']);
		$getTotalPD = $this -> model_account_customer ->getTotalPD($this->session->data['customer_id']);
		
		if (doubleval($getCustomer['total_pd_left']) > doubleval($getCustomer['total_pd_right'])){
			 $balanced = doubleval($getCustomer['total_pd_right']);
		}
		else
		{
			$balanced = doubleval($getCustomer['total_pd_left']);
		}
		
		if (doubleval($balanced) <= 1000000000){
			$precent = 8;
		}
		if ($balanced < 2000000000 && $balanced > 1000000000){
			$precent = 10;
		}
		if ($balanced >= 2000000000 ){
			$precent = 12;
		}
		$amount = ($balanced*$precent)/100;
		if (doubleval($amount) > (doubleval($getTotalPD['number'])*4))
		{
			$amount = (doubleval($getTotalPD['number']))*4;
		}	
		$json['success'] = $amount;
		return round(($json['success']/100000000),8);
	}
	public function getMWallet(){

		if ($this -> customer -> isLogged() && $this -> session -> data['customer_id']) {
			$this -> load -> model('account/customer');

			// $checkM_Wallet = $this -> model_account_customer -> checkM_Wallet($this -> session -> data['customer_id']);
			// if(intval($checkM_Wallet['number'])  === 0){
			// 	if(!$this -> model_account_customer -> insert_M_Wallet($this -> session -> data['customer_id'])){
			// 		die();
			// 	}
			// }
			$total = $this -> model_account_customer -> get_M_Wallet($this -> session -> data['customer_id']);
			$total = count($total) > 0 ? $total['amount'] : 0;
			
			$json['success'] = $total;
			
			$total = null;
			$json['success'] = round(($json['success']/100000000),8);
			$this -> response -> setOutput(json_encode($json));
		}
	}

	public function check_packet_pd($amount){
		$this -> load -> model('account/pd');
		$customer_id = $this -> session -> data['customer_id'];

		return $this -> model_account_pd -> check_packet_pd($customer_id, $amount);
	}

	public function packet_invoide(){
		$this -> load -> model('account/pd');
		$package = $this -> model_account_pd -> get_invoide($this -> request -> get ['invest']);
		$json['input_address'] = $package['input_address'];



		$json['amount'] =  $package['amount_inv'];
		$json['pin'] = $package['amount_inv'] - $package['pd_amount'];
		$json['package'] = $package['pd_amount'];
		$this->response->setOutput(json_encode($json));
	}

}
