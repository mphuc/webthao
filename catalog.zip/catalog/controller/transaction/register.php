
<?php
class ControllerTransactionRegister extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/transaction/register.js');
			
		};

		//!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		//$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		$this -> load -> model('customize/country');
		$data['country'] = $this -> model_customize_country -> getCountry();
		
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/register.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/register.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	public function register_submit(){
		

		if ($this->request->server['REQUEST_METHOD'] === 'POST'){
			//print_r($this->request); die;
			
			$this -> load -> model('customize/register');
			$this -> load -> model('account/auto');
			$this -> load -> model('transaction/customer');
			$filename = html_entity_decode($this->request->files['avatar']['name'], ENT_QUOTES, 'UTF-8');

			$filename = str_replace(' ', '_', $filename);
			if(!$filename || !$this->request->files){
				die();
			}

			$file = $this -> request -> post['token'].'_'.$filename . '.' . md5(mt_rand()) ;


			move_uploaded_file($this->request->files['avatar']['tmp_name'], DIR_UPLOAD . $file);
			$server = $this -> request -> server['HTTPS'] ? $this -> config -> get('config_ssl') :  $this -> config -> get('config_url');
			$linkImage = $server . 'system/upload/'.$file;

			$img_profile = $linkImage;
			$check_username = $this -> model_transaction_customer -> check_username($this -> db -> escape($this->request->post['username']));
			//(intval($check_username) > 0) && die();
			$cus_id = $this -> model_transaction_customer -> addCustomer_custom($this->request->post,$img_profile);
			$amount = 0;
			$code_active = sha1(md5(md5($cus_id)));
			$this -> model_customize_register -> insert_code_active($cus_id, $code_active);
			// send mail
			$mail = new Mail();
			$mail -> protocol = $this -> config -> get('config_mail_protocol');
			$mail -> parameter = $this -> config -> get('config_mail_parameter');
			$mail -> smtp_hostname = $this -> config -> get('config_mail_smtp_hostname');
			$mail -> smtp_username = $this -> config -> get('config_mail_smtp_username');
			$mail -> smtp_password = html_entity_decode($this -> config -> get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail -> smtp_port = $this -> config -> get('config_mail_smtp_port');
			$mail -> smtp_timeout = $this -> config -> get('config_mail_smtp_timeout');

			//$mail -> setTo($this -> config -> get('config_email'));
			$mail -> setTo($_POST['email']);
			$mail -> setFrom($this -> config -> get('config_email'));
			$mail -> setSender(html_entity_decode("Coinmax, Inc", ENT_QUOTES, 'UTF-8'));
			$mail -> setSubject("Congratulations Your Registration is Confirmed!");
			$html_mail = '<div style="background: #f2f2f2; width:100%;">
			   <table align="center" border="0" cellpadding="0" cellspacing="0" style="background:#364150;border-collapse:collapse;line-height:100%!important;margin:0;padding:0;
			    width:700px; margin:0 auto">
			   <tbody>
			      <tr>
			        <td>
			          <div style="text-align:center" class="ajs-header"><img  src="'.HTTPS_SERVER.'catalog/view/theme/default/img/logo.png" alt="logo" style="margin: 0 auto; width:150px;"></div>
			        </td>
			       </tr>
			       <tr>
			       <td style="background:#fff">
			       	<p class="text-center" style="font-size:20px;color: black;text-transform: uppercase; width:100%; float:left;text-align: center;margin: 30px 0px 0 0;">congratulations !<p>
			       	<p class="text-center" style="color: black; width:100%; float:left;text-align: center;line-height: 15px;margin-bottom:30px;">You have successfully registered account</p>
   	<div style="width:600px; margin:0 auto; font-size=15px">

				       	<p style="font-size:14px;color: black;margin-left: 70px;">Your Username: <b>'.$this-> request ->post['username'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Email Address: <b>'.$this-> request ->post['email'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Phone Number: <b>'.$this-> request ->post['telephone'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Citizenship Card/Passport No: <b>'.$this-> request ->post['cmnd'].'</b></p>
				       	
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Password For Login: <b>'.$this-> request ->post['password'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Secret question: <b>'.$this-> request ->post['question'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Answers to the secret question: <b>'.$this-> request ->post['answers'].'</b></p>
				      				       	<p style="font-size:14px;color: black;text-align:center;"><a href="'.HTTPS_SERVER.'active_cm.html&token='.$code_active.'" style="margin: 0 auto;width: 200px;background: #d14836;    text-transform: uppercase;
border-radius: 5px;
font-weight: bold;text-decoration:none;color:#f8f9fb;display:block;padding:12px 10px 10px">Active</a></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Bitcoin Wallet: <b>'.$this-> request ->post['wallet'].'</b>	</p>
				       	<p style="text-align:center;">
				       		<img style="margin:0 auto" src="https://chart.googleapis.com/chart?chs=150x150&chld=L|1&cht=qr&chl=bitcoin:'.$this-> request ->post['wallet'].'"/>
				       	</p>
				       	

				          </div>
			       </td>
			       </tr>
			    </tbody>
			    </table>
			  </div>';
			$mail -> setHtml($html_mail); 
			
			$mail -> send();

			// send mail admin
			date_default_timezone_set('Asia/Ho_Chi_Minh');
			$mail = new Mail();
			$mail->protocol = $this->config->get('config_mail_protocol');
			$mail->parameter = 'mmocoimax@gmail.com';
			$mail->smtp_hostname = 'ssl://smtp.gmail.com';
			$mail->smtp_username = 'mmocoimax@gmail.com';
			$mail->smtp_password = 'ibzfqpduhwajikwx';
			$mail->smtp_port = '465';
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
			$mail->setTo('trungdoanict@gmail.com');
			$mail->setFrom('mmocoimax@gmail.com');
			$mail->setSender('Coinmax');
			$mail -> setSubject("Registration is ".$this-> request ->post['username']." - ".date('d/m/Y H:i:s')."");
			$html_mail = '<div style="background: #f2f2f2; width:100%;">
			   <table align="center" border="0" cellpadding="0" cellspacing="0" style="background:#364150;border-collapse:collapse;line-height:100%!important;margin:0;padding:0;
			    width:700px; margin:0 auto">
			   <tbody>
			      <tr>
			        <td>
			          <div style="text-align:center" class="ajs-header"><img  src="'.HTTPS_SERVER.'catalog/view/theme/default/img/logo.png" alt="logo" style="margin: 0 auto; width:150px;"></div>
			        </td>
			       </tr>
			       <tr>
			       <td style="background:#fff">
			       	<p class="text-center" style="font-size:20px;color: black;text-transform: uppercase; width:100%; float:left;text-align: center;margin: 30px 0px 0 0;">congratulations !<p>
			       	<p class="text-center" style="color: black; width:100%; float:left;text-align: center;line-height: 15px;margin-bottom:30px;">You have successfully registered account</p>
   	<div style="width:600px; margin:0 auto; font-size=15px">

				       	<p style="font-size:14px;color: black;margin-left: 70px;">Your Username: <b>'.$this-> request ->post['username'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Email Address: <b>'.$this-> request ->post['email'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Phone Number: <b>'.$this-> request ->post['telephone'].'</b></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Citizenship Card/Passport No: <b>'.$this-> request ->post['cmnd'].'</b></p>
				       	
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Password For Login: <b>'.$this-> request ->post['password'].'</b></p>
				       	
				      				       	<p style="font-size:14px;color: black;text-align:center;"><a href="'.HTTPS_SERVER.'active.html&token='.$code_active.'" style="margin: 0 auto;width: 200px;background: #d14836;    text-transform: uppercase;
border-radius: 5px;
font-weight: bold;text-decoration:none;color:#f8f9fb;display:block;padding:12px 10px 10px">Active</a></p>
				       	<p style="font-size:14px;color: black;margin-left: 70px;">Bitcoin Wallet: <b>'.$this-> request ->post['wallet'].'</b>	</p>
				       	<p style="text-align:center;">
				       		<img style="margin:0 auto" src="https://chart.googleapis.com/chart?chs=150x150&chld=L|1&cht=qr&chl=bitcoin:'.$this-> request ->post['wallet'].'"/>
				       	</p>
				       	

				          </div>
			       </td>
			       </tr>
			    </tbody>
			    </table>
			  </div>';
			$mail -> setHtml($html_mail); 
			//$mail->send();

			//end send mail admin
			//print_r($mail); die;
			//die();
			$this-> model_customize_register -> update_template_mail($code_active, $html_mail);
			$this->session->data['register_mail'] = $this-> request ->post['email'];
			$this -> response -> redirect('index.php?route=transaction/register/signup_success');
			
		}

	}

	public function active(){

		$this -> load -> model('customize/register');
		$this -> load -> model('account/customer');
		$this -> load -> model('transaction/customer');
		$get_customer_code_active = $this -> model_transaction_customer -> get_customer_code_active($this->request->get['token']);
		if ($get_customer_code_active['status'] == 0){
			$this->model_customize_register->update_code_active($this->request->get['token']);
			$get_customer_code_active = $this -> model_transaction_customer -> get_customer_code_active($this->request->get['token']);
			$cus_id = $get_customer_code_active['customer_id'];

			$check_blockio_Wallet = $this -> model_account_customer -> check_wallet_blockio($cus_id);
			if(intval($check_blockio_Wallet)  === 0){
				$label = $cus_id."-".rand(10,99);
				$wallet_blockio = $this -> create_wallet_blockio($label);
				if(!$this -> model_account_customer ->insert_wallet_blockio(0, $cus_id,$wallet_blockio,$label)) {
					die();
				}
			}
			$check_coinmax_Wallet = $this -> model_account_customer -> check_wallet_coinmax($cus_id);
			if(intval($check_coinmax_Wallet)  === 0){
				$wallet_coinmax = $this -> create_wallet_coinmax($cus_id);
				if(!$this -> model_account_customer ->insert_wallet_coinmax(0, $cus_id,$wallet_coinmax))
				{
					die();
				}
			}
		}
		$this -> response -> redirect(HTTPS_SERVER . 'login_cm.html#success');
	}

	public function create_wallet_blockio($lable){
		$block_io = new BlockIo(key, pin, block_version);
		$wallet = $block_io->get_new_address(array('label' => $lable));
		return $wallet->data->address;
	}

	public function get_address_balance($address){
		$block_io = new BlockIo(key, pin, block_version);
		$balances = $block_io->get_address_balance(array('addresses' => $address));
		$balances['available_balance'] = $balances->data->available_balance;
		$balances['pending_received_balance'] = $balances->data->pending_received_balance;
		return $balances;
	}

	public function create_wallet_coinmax($customercode) {
		$length = 33;
		$str ="";
		$secret = substr(hash_hmac('sha1', hexdec(crc32(md5($customercode))), 'secret'), 0, 100);
		$chars = $secret."ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$size = strlen( $chars );
		for( $i = 0; $i < $length; $i++ ) {
		$str .= $chars[ rand( 0, $size - 1 ) ];
		 }
		return '7'.$str;
	}
	public function signup_success(){
		if ($this->request->server['HTTPS']) {
			$server = $this->config->get('config_ssl');
		} else {
			$server = $this->config->get('config_url');
		}
		$data['base'] = $server;

		if (isset($this -> session -> data['register_mail'])) {
			$data['register_mail'] = $this -> session -> data['register_mail'];

			unset($this -> session -> data['register_mail']);
		} else {
			$data['register_mail'] = '';
		}

		//end load country model

		//data render website
		$data['self'] = $this;


		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/signup_success.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/signup_success.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/signup_success.tpl', $data));
		}
	}
	public function submit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$numbtc = array_key_exists('numbtc', $this -> request -> post) ? $this -> request -> post['numbtc'] : "Error";
			$amount = array_key_exists('amount', $this -> request -> post) ? $this -> request -> post['amount'] : "Error";
			$price = array_key_exists('price', $this -> request -> post) ? $this -> request -> post['price'] : "Error";
			$wallet = array_key_exists('wallet', $this -> request -> post) ? $this -> request -> post['wallet'] : "Error";
			if ($numbtc == "Error" || $amount == "Error" || $price == "Error" || $wallet == "Error" ) {
				$json['error'] = -1;
				
			}
			//buy
			$this -> load -> model('transaction/customer');
			
			$get_gd_create = $data['get_gd_create'] = $this -> model_transaction_customer -> get_pd_create($this->request->post['token']);
			count($data['get_gd_create']) == 0 && $this -> response -> redirect("/login.html");
			$block_io = new BlockIo(key, pin, block_version);
			$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio();
			$label = $get_wallet_blockio['label'];
			
			$balnce = $block_io->get_address_balance(array('labels' => $label));
			$data['blance'] = $balnce->data->available_balance;
			$data['amount_coinmax'] = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
			if ($get_gd_create['status'] == 0)
			{

				if (floatval($data['get_gd_create']['amount']) >= floatval($amount) && $data['amount_coinmax'] >= $amount || 1==1) 
				{

					//$this -> model_transaction_customer -> update_status_pd($data['get_gd_create']['id'],"1");
					$data = array(	'pd_id' => $data['get_gd_create']['id'], 
									'gd_id' => 0,
									'pd_id_customer' => $data['get_gd_create']['customer_id'],
									'gd_id_customer' => $this->session->data['customer_id'],
									'price' => $price,
									'amount' => $amount,
									'numbtc' => $numbtc*100000000,
									'wallet' => $wallet);
					
					$create_tranfer = $this -> model_transaction_customer ->create_tranfer($data);

					$json['create_tranfer'] = $create_tranfer['transfer_code'];
					
					if (floatval($get_gd_create['filled']) - floatval($numbtc*100000000) > 0)
					{
						$this -> model_transaction_customer -> create_sell($get_gd_create['customer_id'],floatval($get_gd_create['amount']) - floatval($amount),$get_gd_create['price'],floatval($get_gd_create['filled']) - floatval($numbtc*100000000));
					}
					$this -> model_transaction_customer -> update_status_pd($get_gd_create['id'],"1");
					//$this -> model_transaction_customer ->update_pd($get_gd_create['id'],$pd_status,$amount,$numbtc*100000000);
					
					
					$json['url'] = $this->url-> link('transaction/sell/trade_sell&token='.$create_tranfer['transfer_code']);
					$this->response->setOutput(json_encode($json));
				}
				else
				{
					$json['error'] = -1;
					$this->response->setOutput(json_encode($json));
				}
			}
			else
			{
				$json['transaction'] = -1;
				$this->response->setOutput(json_encode($json));
			}
			
			
		}
	}
	public function get_blance_wallet($customer_id){
		$this -> load -> model('transaction/customer');
		$block_io = new BlockIo(key, pin, block_version);
		$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio_buy_customer_id($customer_id);
		$label = $get_wallet_blockio['label'];
		$balnce = $block_io->get_address_balance(array('labels' => $label));
		return $data['blance'] = $balnce->data->available_balance;
	}
	public function get_wallet_coinmax($customer_id){
		$this -> load -> model('transaction/customer');
		return $data['amount_coinmax'] = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($customer_id);
	}
	public function trade_sell(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/countdown/jquery.countdown.min.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/countdown.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/trade_finish.js');
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		$data['url_confirm_sell'] = $this -> url -> link('transaction/sell/update_status_tranferlist_pd&token='.$this->request->get['token']);
		$data['url_confirm_buy'] = $this -> url -> link('transaction/sell/update_status_tranferlist_gd&token='.$this->request->get['token']);
		$data['url_send'] = $this -> url -> link('transaction/sell/send&token='.$this->request->get['token']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/trade_sell.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/trade_sell.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	
	public function getCustomer_buyid($customer_id){
		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> getCustomer_buyid($customer_id);
	}
	public function get_pd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_pd_username($id_gd);
	}

	public function getCustomer_wallet($customer_id){

		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> getCustomer_wallet($customer_id);
	}

	public function update_status_tranferlist_pd(){

		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		$this -> model_transaction_customer -> update_status_pd($get_tranferlist['pd_id'],2);
		$getCustomer_buyid = $this->getCustomer_buyid($get_tranferlist['gd_id_customer']);
		//print_r($get_tranferlist); 
		$mail = new Mail();
		$mail->protocol = $this->config->get('config_mail_protocol');
		$mail->parameter = 'mmocoimax@gmail.com';
		$mail->smtp_hostname = 'ssl://smtp.gmail.com';
		$mail->smtp_username = 'mmocoimax@gmail.com';
		$mail->smtp_password = 'ibzfqpduhwajikwx';
		$mail->smtp_port = '465';
		$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
		$mail->setTo('trungict1994@gmail.com');
		//$mail->setTo($this->getCustomer_buyid($get_tranferlist['pd_id_customer'])['email']);
		$mail->setFrom('mmocoimax@gmail.com');
		$mail->setSender('Coinmax Payment');
		$mail -> setSubject("Transaction Confirmation width ".$getCustomer_buyid['username']."");
		$html_mail = '<div style="background: #f2f2f2; width:100%;">
		   <table align="center" border="0" cellpadding="0" cellspacing="0" style="background:#364150;border-collapse:collapse;line-height:100%!important;margin:0;padding:0;
		    width:700px; margin:0 auto">
		   <tbody>
		      <tr>
		        <td>
		          <div style="text-align:center" class="ajs-header"><img  src="'.HTTPS_SERVER.'catalog/view/theme/default/img/logo.png" alt="logo" style="margin: 0 auto; width:150px;"></div>
		        </td>
		       </tr>
		       <tr>
		       <td style="background:#fff">
		       	<p class="text-center" style="font-size:20px;color: black;text-transform: uppercase; width:100%; float:left;text-align: center;margin: 30px 0px 0 0;">Transaction Confirmation !<p>
		       	<p class="text-center" style="color: black; width:100%; float:left;text-align: center;line-height: 15px;margin-bottom:30px;">You have successfully registered account</p>
       	<div style="width:600px; margin:0 auto; font-size=15px">
				<p style="font-size:14px;color: black;margin-left: 70px;">Username <b>'.$getCustomer_buyid['username'].'</b> are asking your purchase <b>'.($get_tranferlist['numbtc']/100000000).'</b> BTC with CMP <b>'.number_format($get_tranferlist['amount']).'</b> CMP</b></p>
					<p style="font-size:14px;color: black;margin-left: 70px;">Please confirm the transaction to be completed!</b></p>
					<p style="font-size:14px;color: black;text-align:center;"><a href="'.$this->url->link('transaction/transaction/sell&token='.$get_tranferlist['transfer_code'].'').'" style="margin: 0 auto;width: 240px;background: #d14836;    text-transform: uppercase;
    border-radius: 5px;
    font-weight: bold;text-decoration:none;color:#f8f9fb;display:block;padding:12px 10px 10px">Go to the confirmation page</a></p>

		</div>
					       
		       </td>
		       </tr>
		    </tbody>
		    </table>
		  </div>';
		$mail -> setHtml($html_mail); 
		
		$mail->send();
		//print_r($mail); die;
		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function update_status_tranferlist_gd(){
		
		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function send(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		// update coin
		
		//send bitcoi
		/*$block_io = new BlockIo(key, pin, block_version);
		$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
											'from_labels' => $label_send, 
											'to_labels' => $label_to));*/

	}

}
