<?php
class ControllerTransactionTranfercm extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/tranfercm.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		$data['price_sell'] = $this->config->get('price_sell');
		$data['price_buy'] = $this->config->get('price_buy');
		$data['url_submit'] = $this ->url->link('transaction/create/submit');
		$data['url_sell'] = $this ->url->link('transaction/tranfer/sell');
		$data['url_buy'] = $this ->url->link('transaction/tranfer/buy');
		
		$data['amount'] = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
		$data['get_question_transaction'] = $this-> model_transaction_customer -> get_question_transaction($this->session->data['customer_id'])['question'];
		$data['wallet'] = $this -> model_transaction_customer -> get_all_wallet($this -> session -> data['customer_id']);

		$block_io = new BlockIo(key, pin, block_version);
		$balances = $block_io->get_address_balance(array('addresses' => $data['wallet']['blockio']));
		//print_r($balances); die;
		$data['blance_blockio'] = $balances->data->available_balance;
		$data['blance_blockio_pending'] = $balances->data->pending_received_balance;
		
		$amount_blockchain = file_get_contents("https://blockchain.info/q/addressbalance/".$data['wallet']['blockchain']."");
		$data['amount_blockchain'] = floatval($amount_blockchain)/100000000;

		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/tranfercm.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/tranfercm.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	
	public function submit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$this -> load -> model('transaction/customer');
		if ($this -> request -> post){
			
			$amount = array_key_exists('amount', $this -> request -> post) ? $this -> request -> post['amount'] : "Error";
			$username = array_key_exists('amount', $this -> request -> post) ? $this -> request -> post['username'] : "Error";
			$password_transaction = array_key_exists('password_transaction', $this -> request -> post) ? $this -> request -> post['password_transaction'] : "Error";
			if ($amount == "Error" || $username == "Error" || $password_transaction == "Error") {
				$json['error'] = -1;
				
			}
			$check_password_transaction = $this -> model_transaction_customer -> check_password_transaction($this->session->data['customer_id'],$password_transaction);
			if ($check_password_transaction > 0)
			{
				$amount = doubleval(str_replace(",","",$amount));
				$amount_coinmax = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
				if ($amount_coinmax >= $amount){
					$getcustomer_buy_username = $this-> model_transaction_customer ->getcustomer_buy_username($username);


					$this-> model_transaction_customer -> update_coinmax($getcustomer_buy_username['customer_id'],$amount,$add=true);
					$this-> model_transaction_customer -> update_coinmax($this->session->data['customer_id'],$amount,$add=false);
					
					$this -> model_transaction_customer -> saveTranstionHistory($this->session->data['customer_id'],0, $amount,$this->get_blance_coinmax($this->session->data['customer_id']), "Send to ".$this->getid_customer($getcustomer_buy_username['customer_id'])." ".number_format($amount)." CMP from transaction CMP", 0);

					$this -> model_transaction_customer -> saveTranstionHistory($getcustomer_buy_username['customer_id'],$amount,0,$this->get_blance_coinmax($getcustomer_buy_username['customer_id']),"Receive ".number_format($amount)." CMP from ".$this->getid_customer($this->session->data['customer_id'])." from transaction CMP", 0);

					$json['succsess'] = 1;
				}
				else
				{
					$json['error'] = -1;
				}
			}
			else
			{
				$json['password'] = -1;
			}
			$this->response->setOutput(json_encode($json));
		}
	}

	public function submit_my_transaction(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$this -> load -> model('transaction/customer');
		if ($this -> request -> post){
			
			$amount = array_key_exists('amount_btc', $this -> request -> post) ? $this -> request -> post['amount_btc'] : "Error";
			$password_transaction = array_key_exists('password_transaction_btc', $this -> request -> post) ? $this -> request -> post['password_transaction_btc'] : "Error";
			if ($amount == "Error" || $password_transaction == "Error") {
				$json['error'] = -1;
				
			}
			$check_password_transaction = $this -> model_transaction_customer -> check_password_transaction($this->session->data['customer_id'],$password_transaction);
			if ($check_password_transaction > 0)
			{
					$data['wallet'] = $this -> model_transaction_customer -> get_all_wallet($this -> session -> data['customer_id']);

					$block_io = new BlockIo(key, pin, block_version);
					$balances = $block_io->get_address_balance(array('addresses' => $data['wallet']['blockio']));
					$blance_blockio = $balances->data->available_balance;
				if ($blance_blockio >= $amount){
					//echo $amount." ".$data['wallet']['label_blockio']." ".$data['wallet']['blockchain'];die;
					$block_io->withdraw_from_labels(array('amounts' => $amount,
													 'from_labels' => $data['wallet']['label_blockio'],
													  'to_addresses' => $data['wallet']['blockchain'],
													  'priority' => 'low'
													 ));
					$json['succsess'] = 1;
				}
				else
				{
					$json['error'] = -1;
				}
			}
			else
			{
				$json['password'] = -1;
			}
			$this->response->setOutput(json_encode($json));
		}
	}

	public function get_blance_coinmax($customer_id){
		$this -> load-> model('transaction/customer');
		$get_blance_coinmax = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($customer_id);
		return $get_blance_coinmax['amount'];
	}
	public function getid_customer($customer_id){
		$this -> load-> model('transaction/customer');
		$get_username_all = $this -> model_transaction_customer -> get_username_all($customer_id);
		return "ID".substr($get_username_all['customer_code'],0,6);
	}
	public function get_username($customer_id){
		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> get_username($customer_id);
	}
	public function load_wallet_coinmax(){
		$this -> load -> model('transaction/customer');
		$username = $this-> request->post['username'];
		$load_wallet_coinmax = $this -> model_transaction_customer -> load_wallet_coinmax($username);
		$load_wallet_coinmax = json_encode($load_wallet_coinmax);
		$this->response->setOutput(json_encode($load_wallet_coinmax));
	}
	public function getaccount_username(){
		if ($this -> request -> post['keyword']) {
			$this -> load -> model('transaction/customer');
			$tree = $this -> model_transaction_customer -> getCustomLike($this -> request -> post['keyword']);
			
			if (count($tree) > 0) {
				foreach ($tree as $value) {
					if ($value['img_profile'] == "") 
                            $img = "catalog/view/theme/default/style1/img/team/1.jpg";
                    else 
                    		$img = $value['img_profile'];
                                                  
					 echo '<li class="list-group-item" onClick="selectU(' . "'" . $value['name'] . "'" . ')"><img src="'.$img.'" />' . $value['name'] . '</li>';
				}
			}
		}
	}

}
