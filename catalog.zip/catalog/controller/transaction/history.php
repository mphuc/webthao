<?php
class ControllerTransactionHistory extends Controller {
	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> load -> model('transaction/customer');

		};
		
		//method to call function
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect($this -> url -> link('/login.html'));
		call_user_func_array("myConfig", array($this));

		if ($this->request->server['HTTPS']) {
            $server = $this->config->get('config_ssl');
        } else {
            $server = $this->config->get('config_url');
        }
		$data['base'] = $server;
        $data['self'] = $this;
		$this -> load -> model('transaction/customer');
		


        $page = isset($this -> request -> get['p']) ? $this -> request -> get['p'] : 1;

		$limit = 10;
		$start = ($page - 1) * 10;

		$ts_history = $this -> model_transaction_customer -> getTotalHistory($this -> session -> data['customer_id']);

		$ts_history = $ts_history['number'];

		$pagination = new Pagination();
		$pagination -> total = $ts_history;
		$pagination -> page = $page;
		$pagination -> limit = $limit;
		$pagination -> num_links = 5;
		$pagination -> text = 'text';
		$pagination -> url = "index.php?route=transaction/history&p={page}";
		$data['histotys'] = $this -> model_transaction_customer -> getTransctionHistory($this -> session -> data['customer_id'], $limit, $start);

		$data['pagination'] = $pagination -> render();


        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/transaction/history.tpl')) {
            $this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/transaction/history.tpl', $data));
        } else {
            $this->response->setOutput($this->load->view('default/template/transaction/history.tpl', $data));
        }
	}
	
}