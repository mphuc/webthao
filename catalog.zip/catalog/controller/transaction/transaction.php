<?php
class ControllerTransactionTransaction extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/create_transaction.js');
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$this -> load -> model('transaction/transaction');
		$data['self'] = $this;
		$data['price_sell'] = $this->config->get('price_sell');
		$data['price_buy'] = $this->config->get('price_buy');
		$data['url_submit'] = $this ->url->link('transaction/create/submit');
		$data['url_sell'] = $this ->url->link('transaction/sell');
		$data['url_buy'] = $this ->url->link('transaction/buy');
		
		

		$page = isset($this->request->get['page']) ? $this->request->get['page'] : 1;      

		$limit = 10;
		$start = ($page - 1) * 10;
		$buy_total = $this-> model_transaction_transaction ->count_all_transferlist_by_id_buy($this -> session -> data['customer_id']);
		$pagination = new Pagination();
		$pagination->total = $buy_total;
		$pagination->page = $page;
		$pagination->limit = $limit; 
		$pagination->num_links = 5;
		//$pagination->text = 'text';
		$pagination->url = $this->url->link('transaction/transaction', 'page={page}', 'SSL');
		$data['history_buy'] = array();
		$data['history_buy'] = $this -> model_transaction_transaction -> get_all_transferlist_by_id_buy($this -> session -> data['customer_id'],$limit,$start);
		$data['pagination_buy'] = $pagination->render();

		
		$pages = isset($this -> request -> get['pages']) ? $this -> request -> get['pages'] : 1;
		$starts = ($pages - 1) * 10;
		$sell_total = $this-> model_transaction_transaction ->count_all_transferlist_by_id_sell($this -> session -> data['customer_id']);
		$pagination_sell = new Pagination();
		$pagination_sell->total = $sell_total;
		$pagination_sell->page = $pages;
		$pagination_sell->limit = $limit; 
		$pagination_sell->num_links = 5;
		//$pagination->text = 'text';
		$pagination_sell->url = $this->url->link('transaction/transaction', 'pages={page}', 'SSL');
		$data['history_sell'] = array();
		
		$data['history_sell'] = $this -> model_transaction_transaction -> get_all_transferlist_by_id_sell($this -> session -> data['customer_id'],$limit,$starts);
		$data['pagination_sell'] = $pagination_sell->render();
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/transaction.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/transaction.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	public function getCustomer_buyid($customer_id){
		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> getCustomer_buyid($customer_id);
	}
	public function get_blance_wallet($customer_id){
		$this -> load -> model('transaction/customer');
		$block_io = new BlockIo(key, pin, block_version);
		$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio_buy_customer_id($customer_id);
		$label = $get_wallet_blockio['label'];
		$balnce = $block_io->get_address_balance(array('labels' => $label));
		return $data['blance'] = $balnce->data->available_balance;
	}
	public function get_wallet_coinmax($customer_id){
		$this -> load -> model('transaction/customer');
		return $data['amount_coinmax'] = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($customer_id);
	}
	public function buy(){
		$url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$this -> session->data['url_login'] = $url;
 		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/countdown/jquery.countdown.min.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/countdown.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/trade.js');
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		
		$data['url_send'] = $this -> url -> link('transaction/transaction/send_buy&token='.$this->request->get['token']);
		
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/confirm_buy.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/confirm_buy.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	public function sell(){
		$url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$this -> session->data['url_login'] = $url;
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/countdown/jquery.countdown.min.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/countdown.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/trade.js');
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		$data['url_send'] = $this -> url -> link('transaction/transaction/send_sell&token='.$this->request->get['token']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/confirm_sell.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/confirm_sell.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	
	public function get_pd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_pd_username($id_gd);
	}
	public function get_gd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_gd_username($id_gd);
	}
	public function getCustomer_wallet($customer_id){

		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> getCustomer_wallet($customer_id);
	}
	public function get_username($customer_id){
		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> get_username($customer_id);
	}
	public function update_status_tranferlist_pd(){

		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		$this -> model_transaction_customer -> update_status_pd($get_tranferlist['pd_id'],2);

		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function update_status_tranferlist_gd(){
		
		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function getlable_blockio($customer_id){
		$this -> load -> model('transaction/customer');
		return $this -> model_transaction_customer -> getlable_blockio($customer_id);
	}
	public function send_sell(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');

		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
		//print_r($get_tranferlist); die;
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		if (intval($get_tranferlist['pd_status']) != 2 && intval($get_tranferlist['gd_status']) != 2)
		{

			$block_io = new BlockIo(key, pin, block_version);
			$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio_buy_customer_id($get_tranferlist['pd_id_customer']);
			$label = $get_wallet_blockio['label'];
			$balnce = $block_io->get_address_balance(array('labels' => $label));
			$blance_pd = $balnce->data->available_balance;
			$amount_coinmax_gd = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($get_tranferlist['gd_id_customer'])['amount'];
			//echo $blance_pd." ".$amount_coinmax_gd; die;
			if ($blance_pd >= $get_tranferlist['numbtc']/100000000 && $amount_coinmax_gd >= $get_tranferlist['amount_tf'])
			{
				
				$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
				$this -> model_transaction_customer -> update_status_pd($get_tranferlist['pd_id'],2);
				
				// update coin
				$this-> model_transaction_customer -> update_coinmax($get_tranferlist['gd_id_customer'],$get_tranferlist['amount_tf'],$add=false);
				$this-> model_transaction_customer -> update_coinmax($get_tranferlist['pd_id_customer'],$get_tranferlist['amount_tf'],$add=true);
				
				//send bitcoi

				$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['gd_id_customer'],0,$get_tranferlist['amount_tf'],$this->get_blance_coinmax($get_tranferlist['gd_id_customer']), "Send to ".$this->getid_customer($get_tranferlist['pd_id_customer'])." ".number_format($get_tranferlist['amount_tf'])." CMP from  transaction ".($get_tranferlist['numbtc']/100000000)." BTC", $get_tranferlist['id_tf']);

				$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['pd_id_customer'],$get_tranferlist['amount_tf'],0,$this->get_blance_coinmax($get_tranferlist['pd_id_customer']),"Receive ".number_format($get_tranferlist['amount_tf'])." CMP from ".$this->getid_customer($get_tranferlist['gd_id_customer'])." from transaction ".($get_tranferlist['numbtc']/100000000)." BTC", $get_tranferlist['id_tf']);

				$amount_btc = $get_tranferlist['numbtc']/100000000;
				//$amount_btc = 0.001;
				/* $label_form = "default";
				 $label_to = "vybu91";*/
				
				$label_form = $this->getlable_blockio($get_tranferlist['pd_id_customer'])['label'];
				$label_to = $this->getlable_blockio($get_tranferlist['gd_id_customer'])['label'];
				//print_r($label_to); die;
				 echo "BTC".$amount_btc;echo "<br/>";
				echo "Từ".$label_form;echo "<br/>";
				echo "Đến".$label_to;echo "<br/>";

				$block_io = new BlockIo(key, pin, block_version);
				$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
													'from_labels' => $label_form, 
													'to_labels' => $label_to,
													'priority' => 'low'));
				

				$this -> response -> redirect("index.php?route=transaction/transaction/sell&token=".$this->request->get['token']);
			}
			else{
				$this-> model_transaction_customer -> update_status_status_tranfer($get_tranferlist['id_tf'],1);
				if ($blance_pd < $get_tranferlist['numbtc']/100000000){
					$this -> response -> redirect("index.php?route=transaction/transaction/sell&token=".$this->request->get['token']."#error_pd");
				}
				else
				{
					$this -> response -> redirect("index.php?route=transaction/transaction/sell&token=".$this->request->get['token']."#error_gd");
				}
				
			}
		}
		else
		{
			//die;
			$this -> response -> redirect("index.php?route=transaction/transaction/sell&token=".$this->request->get['token']."#timeover");
		}
		
	}
	public function get_blance_coinmax($customer_id){
		$this -> load-> model('transaction/customer');
		$get_blance_coinmax = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($customer_id);
		return $get_blance_coinmax['amount'];
	}
	public function getid_customer($customer_id){
		$this -> load-> model('transaction/customer');
		$get_username_all = $this -> model_transaction_customer -> get_username_all($customer_id);
		return "ID".substr($get_username_all['customer_code'],0,6);
	}
	public function send_buy(){

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
			$this -> load -> model('transaction/customer');

			$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
			//print_r($get_tranferlist); die;

			count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		if (intval($get_tranferlist['pd_status']) != 2 && intval($get_tranferlist['gd_status']) != 2)
		{	

			$block_io = new BlockIo(key, pin, block_version);
			$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio_buy_customer_id($get_tranferlist['pd_id_customer']);
			$label = $get_wallet_blockio['label'];
			$balnce = $block_io->get_address_balance(array('labels' => $label));
			$blance_pd = $balnce->data->available_balance;
			$amount_coinmax_gd = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($get_tranferlist['gd_id_customer'])['amount'];
			//echo $blance_pd." ".$amount_coinmax_gd; die;
			if ($blance_pd >= $get_tranferlist['numbtc']/100000000 && $amount_coinmax_gd >= $get_tranferlist['amount_tf'])
			{

				$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);
				$this -> model_transaction_customer -> update_status_gd($get_tranferlist['pd_id'],2);
				
				// update coin
				$this-> model_transaction_customer -> update_coinmax($get_tranferlist['gd_id_customer'],$get_tranferlist['amount_tf'],$add=false);
				$this-> model_transaction_customer -> update_coinmax($get_tranferlist['pd_id_customer'],$get_tranferlist['amount_tf'],$add=true);
				
				
				$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['gd_id_customer'],0,$get_tranferlist['amount_tf'],$this->get_blance_coinmax($get_tranferlist['gd_id_customer']), "Send to ".$this->getid_customer($get_tranferlist['pd_id_customer'])." ".number_format($get_tranferlist['amount_tf'])." CMP from  transaction ".($get_tranferlist['numbtc']/100000000)." BTC", $get_tranferlist['id_tf']);

				$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['pd_id_customer'],$get_tranferlist['amount_tf'],0,$this->get_blance_coinmax($get_tranferlist['pd_id_customer']),"Receive ".number_format($get_tranferlist['amount_tf'])." CMP from ".$this->getid_customer($get_tranferlist['gd_id_customer'])." from transaction ".($get_tranferlist['numbtc']/100000000)." BTC", $get_tranferlist['id_tf']);


				// update PD
				//send bitcoi
				$amount_btc = $get_tranferlist['numbtc']/100000000;
				//$amount_btc = 0.001;
				/* $label_form = "default";
				 $label_to = "vybu91";*/
				$label_form = $this->getlable_blockio($get_tranferlist['pd_id_customer'])['label'];
				$label_to = $this->getlable_blockio($get_tranferlist['gd_id_customer'])['label'];
				//print_r($label_to); die;
				$block_io = new BlockIo(key, pin, block_version);
				 echo "BTC".$amount_btc;echo "<br/>";
				echo "Từ".$label_form;echo "<br/>";
				echo "Đến".$label_to;echo "<br/>";
				$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
													'from_labels' => $label_form, 
													'to_labels' => $label_to,
													'priority' => 'low'
													));
				
				$this -> response -> redirect("index.php?route=transaction/transaction/buy&token=".$this->request->get['token']);
			}
			else{

				$this-> model_transaction_customer -> update_status_status_tranfer($get_tranferlist['id_tf'],1);
				
				if ($blance_pd < $get_tranferlist['numbtc']/100000000){
					$this -> response -> redirect("index.php?route=transaction/transaction/buy&token=".$this->request->get['token']."#error_ppd");
				}
				else
				{
					$this -> response -> redirect("index.php?route=transaction/transaction/buy&token=".$this->request->get['token']."#error_ggd");
				}
			}
		}
		else
		{
			$this -> response -> redirect("index.php?route=transaction/transaction/buy&token=".$this->request->get['token']."#timeover");
		}
	}

	public function show_bill(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');

		$get_tranferlist = $this -> model_transaction_customer -> get_bill($this->request->post['tranfer_code']);
		/*print_r($get_tranferlist);die;*/
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		$this->response->setOutput(json_encode($get_tranferlist));
	}
}
