<?php
class ControllerTransactionCreate extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/create_transaction.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		$data['price_sell'] = $this->config->get('price_sell');
		$data['price_buy'] = $this->config->get('price_buy');
		$data['url_submit'] = $this ->url->link('transaction/create/submit');
		$data['url_sell'] = $this ->url->link('transaction/tranfer/sell');
		$data['url_buy'] = $this ->url->link('transaction/tranfer/buy');
		$block_io = new BlockIo(key, pin, block_version);
		$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio();

		$balnce = $block_io->get_address_balance(array('labels' => $get_wallet_blockio['label']));
		$data['balnce'] = $balnce->data->available_balance;
		
		$data['amount'] = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
		
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/create.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/create.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	
	public function submit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/create_transaction.js');
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$transaction = array_key_exists('transaction', $this -> request -> post) ? $this -> request -> post['transaction'] : "Error";
			$amount = array_key_exists('amount', $this -> request -> post) ? $this -> request -> post['amount'] : "Error";
			$price = array_key_exists('price', $this -> request -> post) ? $this -> request -> post['price'] : "Error";
			$numbtc = array_key_exists('numbtc', $this -> request -> post) ? $this -> request -> post['numbtc'] : "Error";
			if ($transaction == "Error" || $amount == "Error" || $price == "Error" || $amount == "Error" ) {
				$json['error'] = -1;
				
			}
			$price = doubleval(str_replace(",","",$price));
			$amount = doubleval(str_replace(",","",$amount));
			//buy
			$this -> load -> model('transaction/customer');
			$block_io = new BlockIo(key, pin, block_version);
			$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio();

			$balnce = $block_io->get_address_balance(array('labels' => $get_wallet_blockio['label']));
			$balnce = $balnce->data->available_balance;
			
			$amount_coinmax = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];

			
			if (intval($transaction) == 1 ){
				if ($amount_coinmax >= $amount)
				{
					$create_buy = $this -> model_transaction_customer ->create_buy($this->session->data['customer_id'],$amount,$price,$numbtc*100000000);
					$json['success_buy'] = $create_buy['gd_number'];
				}
				else
				{
					$json['error'] = -1;
				}
				
			}
			else //sell
			{
				if (floatval($balnce) >= $numbtc){
					$create_sell = $this -> model_transaction_customer ->create_sell($this->session->data['customer_id'],$amount,$price,$numbtc*100000000);
					$json['success_sell'] = $create_sell['pd_number'];
				}
				else
				{
					$json['error'] = -1;
				}
				
			}
			
			$this->response->setOutput(json_encode($json));
		}
	}

}
