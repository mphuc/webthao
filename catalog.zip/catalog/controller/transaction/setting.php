<?php
class ControllerTransactionSetting extends Controller {
	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> load -> model('transaction/customer');
			$self -> document -> addScript('catalog/view/javascript/transaction/setting.js');

		};
		
		//method to call function
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect($this -> url -> link('/login.html'));
		call_user_func_array("myConfig", array($this));

		if ($this->request->server['HTTPS']) {
            $server = $this->config->get('config_ssl');
        } else {
            $server = $this->config->get('config_url');
        }
		$data['base'] = $server;
        $data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['getCustomer_buyid'] = $this ->model_transaction_customer-> getCustomer_buyid($this->session->data['customer_id']);
		$data['wallet'] = $this -> model_transaction_customer -> get_all_wallet($this -> session -> data['customer_id']);

		$block_io = new BlockIo(key, pin, block_version);
		$balances = $block_io->get_address_balance(array('addresses' => $data['wallet']['blockio']));
		//print_r($balances); die;
		$data['blance_blockio'] = $balances->data->available_balance;
		$data['blance_blockio_pending'] = $balances->data->pending_received_balance;
		
		$amount_blockchain = file_get_contents("https://blockchain.info/q/addressbalance/".$data['wallet']['blockchain']."");
		$data['amount_blockchain'] = floatval($amount_blockchain)/100000000;

        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/transaction/setting.tpl')) {
            $this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/transaction/setting.tpl', $data));
        } else {
            $this->response->setOutput($this->load->view('default/template/transaction/setting.tpl', $data));
        }
	}
	
}