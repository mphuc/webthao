<?php
class ControllerTransactionSell extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/sell.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		$data['url_submit'] = $this ->url->link('transaction/sell/submit');
		$data['getsell'] = array();
		$data['getsell'] = $this -> model_transaction_customer ->get_pd_create($this->request->get['token']);
		$data['getCustomer_wallet'] = $this -> model_transaction_customer ->getCustomer_wallet($this->session->data['customer_id']);
		$block_io = new BlockIo(key, pin, block_version);
		$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio();
		
		$label = $get_wallet_blockio['label'];

		$balnce = $block_io->get_address_balance(array('labels' => $label));
		$data['blance'] = $balnce->data->available_balance;
		$data['amount_coinmax'] = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
		
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/sell.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/sell.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	public function submit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$numbtc = array_key_exists('numbtc', $this -> request -> post) ? $this -> request -> post['numbtc'] : "Error";
			$amount = array_key_exists('amount', $this -> request -> post) ? $this -> request -> post['amount'] : "Error";
			$price = array_key_exists('price', $this -> request -> post) ? $this -> request -> post['price'] : "Error";
			$wallet = array_key_exists('wallet', $this -> request -> post) ? $this -> request -> post['wallet'] : "Error";
			if ($numbtc == "Error" || $amount == "Error" || $price == "Error" || $wallet == "Error" ) {
				$json['error'] = -1;
				
			}
			//buy
			$this -> load -> model('transaction/customer');
			
			$get_gd_create = $data['get_gd_create'] = $this -> model_transaction_customer -> get_pd_create($this->request->post['token']);
			count($data['get_gd_create']) == 0 && $this -> response -> redirect("/login.html");
			$block_io = new BlockIo(key, pin, block_version);
			$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio();
			$label = $get_wallet_blockio['label'];
			
			$balnce = $block_io->get_address_balance(array('labels' => $label));
			$data['blance'] = $balnce->data->available_balance;
			$data['amount_coinmax'] = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
			if ($get_gd_create['status'] == 0)
			{

				if (floatval($data['get_gd_create']['amount']) >= floatval($amount) && $data['amount_coinmax'] >= $amount) 
				{

					//$this -> model_transaction_customer -> update_status_pd($data['get_gd_create']['id'],"1");
					$data = array(	'pd_id' => $data['get_gd_create']['id'], 
									'gd_id' => 0,
									'pd_id_customer' => $data['get_gd_create']['customer_id'],
									'gd_id_customer' => $this->session->data['customer_id'],
									'price' => $price,
									'amount' => $amount,
									'numbtc' => $numbtc*100000000,
									'wallet' => $wallet);
					
					$create_tranfer = $this -> model_transaction_customer ->create_tranfer($data);

					$json['create_tranfer'] = $create_tranfer['transfer_code'];
					
					if (floatval($get_gd_create['filled']) - floatval($numbtc*100000000) > 0)
					{
						$this -> model_transaction_customer -> create_sell($get_gd_create['customer_id'],floatval($get_gd_create['amount']) - floatval($amount),$get_gd_create['price'],floatval($get_gd_create['filled']) - floatval($numbtc*100000000));
					}
					$this -> model_transaction_customer -> update_status_pd($get_gd_create['id'],"1");
					//$this -> model_transaction_customer ->update_pd($get_gd_create['id'],$pd_status,$amount,$numbtc*100000000);
					
					
					$json['url'] = $this->url-> link('transaction/sell/trade_sell&token='.$create_tranfer['transfer_code']);
					$this->response->setOutput(json_encode($json));
				}
				else
				{
					$json['error'] = -1;
					$this->response->setOutput(json_encode($json));
				}
			}
			else
			{
				$json['transaction'] = -1;
				$this->response->setOutput(json_encode($json));
			}
			
			
		}
	}
	public function get_blance_wallet($customer_id){
		$this -> load -> model('transaction/customer');
		$block_io = new BlockIo(key, pin, block_version);
		$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio_buy_customer_id($customer_id);
		$label = $get_wallet_blockio['label'];
		$balnce = $block_io->get_address_balance(array('labels' => $label));
		return $data['blance'] = $balnce->data->available_balance;
	}
	public function get_wallet_coinmax($customer_id){
		$this -> load -> model('transaction/customer');
		return $data['amount_coinmax'] = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($customer_id);
	}
	public function trade_sell(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/countdown/jquery.countdown.min.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/countdown.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/trade_finish.js');
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		$data['url_confirm_sell'] = $this -> url -> link('transaction/sell/update_status_tranferlist_pd&token='.$this->request->get['token']);
		$data['url_confirm_buy'] = $this -> url -> link('transaction/sell/update_status_tranferlist_gd&token='.$this->request->get['token']);
		$data['url_send'] = $this -> url -> link('transaction/sell/send&token='.$this->request->get['token']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/trade_sell.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/trade_sell.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	
	public function getCustomer_buyid($customer_id){
		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> getCustomer_buyid($customer_id);
	}
	public function get_pd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_pd_username($id_gd);
	}

	public function getCustomer_wallet($customer_id){

		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> getCustomer_wallet($customer_id);
	}

	public function update_status_tranferlist_pd(){

		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		$this -> model_transaction_customer -> update_status_pd($get_tranferlist['pd_id'],2);
		$getCustomer_buyid = $this->getCustomer_buyid($get_tranferlist['gd_id_customer']);
		//print_r($get_tranferlist); 
		$mail = new Mail();
		$mail->protocol = $this->config->get('config_mail_protocol');
		$mail->parameter = 'mmocoimax@gmail.com';
		$mail->smtp_hostname = 'ssl://smtp.gmail.com';
		$mail->smtp_username = 'mmocoimax@gmail.com';
		$mail->smtp_password = 'ibzfqpduhwajikwx';
		$mail->smtp_port = '465';
		$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');
		$mail->setTo('trungict1994@gmail.com');
		//$mail->setTo($this->getCustomer_buyid($get_tranferlist['pd_id_customer'])['email']);
		$mail->setFrom('mmocoimax@gmail.com');
		$mail->setSender('Coinmax Payment');
		$mail -> setSubject("Transaction Confirmation width ".$getCustomer_buyid['username']."");
		$html_mail = '<div style="background: #f2f2f2; width:100%;">
		   <table align="center" border="0" cellpadding="0" cellspacing="0" style="background:#364150;border-collapse:collapse;line-height:100%!important;margin:0;padding:0;
		    width:700px; margin:0 auto">
		   <tbody>
		      <tr>
		        <td>
		          <div style="text-align:center" class="ajs-header"><img  src="'.HTTPS_SERVER.'catalog/view/theme/default/img/logo.png" alt="logo" style="margin: 0 auto; width:150px;"></div>
		        </td>
		       </tr>
		       <tr>
		       <td style="background:#fff">
		       	<p class="text-center" style="font-size:20px;color: black;text-transform: uppercase; width:100%; float:left;text-align: center;margin: 30px 0px 0 0;">Transaction Confirmation !<p>
		       	<p class="text-center" style="color: black; width:100%; float:left;text-align: center;line-height: 15px;margin-bottom:30px;">You have successfully registered account</p>
       	<div style="width:600px; margin:0 auto; font-size=15px">
				<p style="font-size:14px;color: black;margin-left: 70px;">Username <b>'.$getCustomer_buyid['username'].'</b> are asking your purchase <b>'.($get_tranferlist['numbtc']/100000000).'</b> BTC with CMP <b>'.number_format($get_tranferlist['amount']).'</b> CMP</b></p>
					<p style="font-size:14px;color: black;margin-left: 70px;">Please confirm the transaction to be completed!</b></p>
					<p style="font-size:14px;color: black;text-align:center;"><a href="'.$this->url->link('transaction/transaction/sell&token='.$get_tranferlist['transfer_code'].'').'" style="margin: 0 auto;width: 240px;background: #d14836;    text-transform: uppercase;
    border-radius: 5px;
    font-weight: bold;text-decoration:none;color:#f8f9fb;display:block;padding:12px 10px 10px">Go to the confirmation page</a></p>

		</div>
					       
		       </td>
		       </tr>
		    </tbody>
		    </table>
		  </div>';
		$mail -> setHtml($html_mail); 
		
		$YourPhone = $this -> get_username($get_tranferlist['pd_id_customer'])['telephone'];
		$description = $getCustomer_buyid['username'].' Buy '.($get_tranferlist['numbtc']/100000000).' BTC with '.number_format($get_tranferlist['amount']).' CMP';
		
		$this->send_sms($YourPhone,$description);
		//$mail->send();
		//print_r($mail); die;
		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function get_username($customer_id){
		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> get_username_all($customer_id);
	}
	public function send_sms($YourPhone,$description){
		$APIKey="6341FB9EFA16C4F3DBDBE4F15B9D7B";
		$SecretKey="86CF68BD01032D2E48DD90FDE471D8";
		$content = 'Coinmax Pay - '.$description;
        $ch = curl_init();

		
		$SampleXml = "<RQST>"
                   . "<APIKEY>". $APIKey ."</APIKEY>"
                   . "<SECRETKEY>". $SecretKey ."</SECRETKEY>"                                    
                   . "<ISFLASH>0</ISFLASH>"
           			. "<SMSTYPE>7</SMSTYPE>"
                   . "<CONTENT>". $content ."</CONTENT>"
                   . "<CONTACTS>"
                   . "<CUSTOMER>"
                   . "<PHONE>". $YourPhone ."</PHONE>"
                   . "</CUSTOMER>"                               
                   . "</CONTACTS>"
				   . "</RQST>";
							   		
							   
		curl_setopt($ch, CURLOPT_URL,            "http://api.esms.vn/MainService.svc/xml/SendMultipleMessage_V2/" );
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt($ch, CURLOPT_POST,           1 );
		curl_setopt($ch, CURLOPT_POSTFIELDS,     $SampleXml ); 
		curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/plain')); 

		$result=curl_exec ($ch);		
		$xml = simplexml_load_string($result);

		if ($xml === false) {
			die('Error parsing XML');   
		}

		//now we can loop through the xml structure
		//Tham khao them ve SMSTYPE de gui tin nhan hien thi ten cong ty hay gui bang dau so 8755... tai day :http://esms.vn/SMSApi/ApiSendSMSNormal
		
		print "Ket qua goi API: " . $xml->CodeResult . "\n"; 
	}
	public function update_status_tranferlist_gd(){
		
		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function send(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		// update coin
		
		//send bitcoi
		/*$block_io = new BlockIo(key, pin, block_version);
		$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
											'from_labels' => $label_send, 
											'to_labels' => $label_to));*/

	}

}
