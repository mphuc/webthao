<?php
class ControllerTransactionTransactions extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		
		

		
		$data['self'] = $this;
		
		// getArticles
		$page = isset($this->request->get['page']) ? $this->request->get['page'] : 1;      

		$limit = 10;
		$start = ($page - 1) * 10;
		$buy_total = $this-> model_transaction_customer ->sumGDtransaction_you();
		$pagination = new Pagination();
		$pagination->total = $buy_total;
		$pagination->page = $page;
		$pagination->limit = $limit; 
		$pagination->num_links = 5;
		//$pagination->text = 'text';
		$pagination->url = $this->url->link('transaction/transactions', 'page={page}', 'SSL');
		
		$data['buy'] = $this -> model_transaction_customer -> getGDtransaction_you($limit,$start);
		
		$data['pagination_buy'] = $pagination->render();

		
		$pages = isset($this -> request -> get['pages']) ? $this -> request -> get['pages'] : 1;
		$starts = ($pages - 1) * 10;
		$sell_total = $this-> model_transaction_customer ->sumPDtransaction_you();
		$pagination_sell = new Pagination();
		$pagination_sell->total = $sell_total;
		$pagination_sell->page = $pages;
		$pagination_sell->limit = $limit; 
		$pagination_sell->num_links = 5;
		//$pagination->text = 'text';
		$pagination_sell->url = $this->url->link('transaction/transactions', 'pages={page}', 'SSL');
		
		$data['sell'] = $this -> model_transaction_customer -> getPDtransaction_you($limit,$starts);
		$data['pagination_sell'] = $pagination_sell->render();

		$data['url_sell'] = $this->url->link('transaction/transactions/sell');
		$data['url_buy'] = $this->url->link('transaction/transactions/buy');
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/transactions.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/transactions.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	
	public function buy(){

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$data['url_send'] = $this->url->link('transaction/transactions/send&token='.$this->request->get['token']);
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);

		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/confirm_buy.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/confirm_buy.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	public function getCustomer_buyid($customer_id){
		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> getCustomer_buyid($customer_id);
	}
	public function get_gd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_gb_username($id_gd);
	}

	public function getCustomer_wallet($customer_id){

		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> getCustomer_wallet($customer_id);
	}

	public function update_avatar(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		$filename = html_entity_decode($this->request->files['avatar']['name'], ENT_QUOTES, 'UTF-8');

		$filename = str_replace(' ', '_', $filename);
		if(!$filename || !$this->request->files){
			die();
		}

		$file = $this -> request -> post['token'].'_'.$filename . '.' . md5(mt_rand()) ;


		move_uploaded_file($this->request->files['avatar']['tmp_name'], DIR_UPLOAD . $file);
		$server = $this -> request -> server['HTTPS'] ? $this -> config -> get('config_ssl') :  $this -> config -> get('config_url');
		$linkImage = $server . 'system/upload/'.$file;
		$this -> model_transaction_customer -> update_avartar($this->session->data['customer_id'],$linkImage);
		$this -> response -> redirect("index.php?route=transaction/setting");
	}

}
