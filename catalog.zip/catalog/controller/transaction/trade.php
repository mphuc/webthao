<?php
class ControllerTransactionTrade extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/transaction/trade.js');
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$this -> load -> model('transaction/transaction');
		$data['self'] = $this;
	
		$data['url_sell_delete'] = $this ->url->link('transaction/trade/delete_sell');
		$data['url_buy_delete'] = $this ->url->link('transaction/trade/delete_buy');
		
		

		$page = isset($this->request->get['page']) ? $this->request->get['page'] : 1;      

		$limit = 10;
		$start = ($page - 1) * 10;
		$buy_total = $this-> model_transaction_transaction ->count_gd_customer($this -> session -> data['customer_id']);
		$pagination = new Pagination();
		$pagination->total = $buy_total;
		$pagination->page = $page;
		$pagination->limit = $limit; 
		$pagination->num_links = 5;
		//$pagination->text = 'text';
		$pagination->url = $this->url->link('transaction/trade', 'page={page}', 'SSL');
		$data['history_buy'] = array();
		$data['history_buy'] = $this -> model_transaction_transaction -> get_all_gd($this -> session -> data['customer_id'],$limit,$start);
		$data['pagination_buy'] = $pagination->render();

		
		$pages = isset($this -> request -> get['pages']) ? $this -> request -> get['pages'] : 1;
		$starts = ($pages - 1) * 10;
		$sell_total = $this-> model_transaction_transaction ->count_pd_customer($this -> session -> data['customer_id']);
		$pagination_sell = new Pagination();
		$pagination_sell->total = $sell_total;
		$pagination_sell->page = $pages;
		$pagination_sell->limit = $limit; 
		$pagination_sell->num_links = 5;
		//$pagination->text = 'text';
		$pagination_sell->url = $this->url->link('transaction/trade', 'pages={page}', 'SSL');
		$data['history_sell'] = array();
		
		$data['history_sell'] = $this -> model_transaction_transaction -> get_all_pd($this -> session -> data['customer_id'],$limit,$starts);
		$data['pagination_sell'] = $pagination_sell->render();
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/trade.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/trade.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	public function delete_sell(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/create_transaction.js');
			
		};
		
		$this -> load -> model('transaction/customer');
		$this -> load -> model('transaction/transaction');
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$get_pd_create = $data['get_gd_create'] = $this -> model_transaction_customer -> get_pd_create($this->request->get['token']);
		count($get_pd_create) == 0 && $this -> response -> redirect("/login.html");
		
		$data['self'] = $this;

		$this -> model_transaction_transaction -> update_pd_status($this->request->get['token'],3);
		
		$this -> response -> redirect("index.php?route=transaction/trade");
	}
	public function delete_buy(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/create_transaction.js');
			
		};
		$this -> load -> model('transaction/customer');
		$this -> load -> model('transaction/transaction');
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$get_gd_create = $data['get_gd_create'] = $this -> model_transaction_customer -> get_gd_create($this->request->get['token']);
		
		count($get_gd_create) == 0 && $this -> response -> redirect("/login.html");
		
		$data['self'] = $this;

		$this -> model_transaction_transaction -> update_gd_status($this->request->get['token'],3);
		
		$this -> response -> redirect("index.php?route=transaction/trade");
	}

	public function getCustomer_buyid($customer_id){
		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> getCustomer_buyid($customer_id);
	}
	public function get_blance_wallet($customer_id){
		$this -> load -> model('transaction/customer');
		$block_io = new BlockIo(key, pin, block_version);
		$get_wallet_blockio =  $this -> model_transaction_customer ->get_wallet_blockio_buy_customer_id($customer_id);
		$label = $get_wallet_blockio['label'];
		$balnce = $block_io->get_address_balance(array('labels' => $label));
		return $data['blance'] = $balnce->data->available_balance;
	}
	public function get_wallet_coinmax($customer_id){
		$this -> load -> model('transaction/customer');
		return $data['amount_coinmax'] = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($customer_id);
	}
	public function buy(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		
		$data['url_send'] = $this -> url -> link('transaction/transaction/send_buy&token='.$this->request->get['token']);
		
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/confirm_buy.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/confirm_buy.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	public function sell(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		$data['url_send'] = $this -> url -> link('transaction/transaction/send_sell&token='.$this->request->get['token']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/confirm_sell.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/confirm_sell.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	
	public function get_pd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_pd_username($id_gd);
	}
	public function get_gd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_gd_username($id_gd);
	}
	public function getCustomer_wallet($customer_id){

		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> getCustomer_wallet($customer_id);
	}
	public function get_username($customer_id){
		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> get_username($customer_id);
	}
	public function update_status_tranferlist_pd(){

		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		$this -> model_transaction_customer -> update_status_pd($get_tranferlist['pd_id'],2);

		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function update_status_tranferlist_gd(){
		
		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function getlable_blockio($customer_id){
		$this -> load -> model('transaction/customer');
		return $this -> model_transaction_customer -> getlable_blockio($customer_id);
	}
	public function send_sell(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');

		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		
		$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
		$this -> model_transaction_customer -> update_status_pd($get_tranferlist['pd_id'],2);
		
		// update coin
		$this-> model_transaction_customer -> update_coinmax($get_tranferlist['gd_id_customer'],$get_tranferlist['amount_tf'],$add=true);
		$this-> model_transaction_customer -> update_coinmax($get_tranferlist['pd_id_customer'],$get_tranferlist['amount_tf'],$add=false);
		$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['pd_id_customer'],"Transactions CMP"," - ".$get_tranferlist['amount_tf']." CMP","Send ".$get_tranferlist['amount_tf']." CMP to  ".$this->get_username($get_tranferlist['gd_id_customer'])." | transactions ".($get_tranferlist['numbtc']/100000000)." BTC", $url = '');
		$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['gd_id_customer'],"Transactions CMP"," + ".$get_tranferlist['amount_tf']." CMP","Get ".$get_tranferlist['amount_tf']." CMP from  ".$this->get_username($get_tranferlist['pd_id_customer'])." | transactions ".($get_tranferlist['numbtc']/100000000)." BTC", $url = '');
		//send bitcoi
		$amount_btc = $get_tranferlist['numbtc']/100000000;
		
		
		$label_form = $this->getlable_blockio($get_tranferlist['pd_id_customer'])['label'];
		$label_to = $this->getlable_blockio($get_tranferlist['gd_id_customer'])['label'];
		//print_r($label_to); die;
		 echo "BTC".$amount_btc;echo "<br/>";
		echo "Từ".$label_form;echo "<br/>";
		echo "Đến".$label_to;echo "<br/>";

		$block_io = new BlockIo(key, pin, block_version);
		$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
											'from_labels' => $label_form, 
											'to_labels' => $label_to));
		die();
		$this -> response -> redirect("index.php?route=transaction/transaction/sell&token=".$this->request->get['token']);
	}
	public function send_buy(){

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');

		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
		

		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		
		$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);
		$this -> model_transaction_customer -> update_status_gd($get_tranferlist['pd_id'],2);
		
		// update coin
		$this-> model_transaction_customer -> update_coinmax($get_tranferlist['gd_id_customer'],$get_tranferlist['amount_tf'],$add=true);
		$this-> model_transaction_customer -> update_coinmax($get_tranferlist['pd_id_customer'],$get_tranferlist['amount_tf'],$add=false);
		$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['pd_id_customer'],"Transactions CMP"," - ".$get_tranferlist['amount_tf']." CMP","Send ".$get_tranferlist['amount_tf']." CMP for  ".$this->get_username($get_tranferlist['gd_id_customer'])." | transactions ".($get_tranferlist['numbtc']/100000000)." BTC", $get_tranferlist['id']);
		$this -> model_transaction_customer -> saveTranstionHistory($get_tranferlist['gd_id_customer'],"Transactions CMP"," + ".$get_tranferlist['amount_tf']." CMP","Get ".$get_tranferlist['amount_tf']." CMP from  ".$this->get_username($get_tranferlist['pd_id_customer'])." | transactions ".($get_tranferlist['numbtc']/100000000)." BTC", $get_tranferlist['id']);
		// update PD

		

		//send bitcoi
		$amount_btc = $get_tranferlist['numbtc']/100000000;
		//$amount_btc = 0.001;
		/* $label_form = "default";
		 $label_to = "vybu91";*/
		$label_form = $this->getlable_blockio($get_tranferlist['pd_id_customer'])['label'];
		$label_to = $this->getlable_blockio($get_tranferlist['gd_id_customer'])['label'];
		//print_r($label_to); die;
		$block_io = new BlockIo(key, pin, block_version);
		 echo "BTC".$amount_btc;echo "<br/>";
		echo "Từ".$label_form;echo "<br/>";
		echo "Đến".$label_to;echo "<br/>";
		$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
											'from_labels' => $label_form, 
											'to_labels' => $label_to));
		die;
		$this -> response -> redirect("index.php?route=transaction/transaction/sell&token=".$this->request->get['token']);
	}

	public function show_bill(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');

		$get_tranferlist = $this -> model_transaction_customer -> get_bill($this->request->post['tranfer_code']);
		/*print_r($get_tranferlist);die;*/
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		$this->response->setOutput(json_encode($get_tranferlist));
	}
}
