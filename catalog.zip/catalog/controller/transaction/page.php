<?php
class ControllerTransactionPage extends Controller {
	public function index() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/transaction.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/transaction.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/transaction.tpl', $data));
		}
	}
	public function about() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/buy.js');

		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/p_about.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/p_about.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/p_about.tpl', $data));
		}
	}
	public function rules() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/buy.js');

		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/p_rules.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/p_rules.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/p_rules.tpl', $data));
		}
	}
	public function how() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/buy.js');

		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/p_how.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/p_how.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/p_how.tpl', $data));
		}
	}
	public function read() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/buy.js');

		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/p_read.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/p_read.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/p_read.tpl', $data));
		}
	}
	public function faq() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/buy.js');

		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/p_faq.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/p_faq.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/p_faq.tpl', $data));
		}
	}
	public function get() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/buy.js');

		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/p_get.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/p_get.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/transaction/p_get.tpl', $data));
		}
	}
	
}