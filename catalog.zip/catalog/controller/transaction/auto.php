<?php
class ControllerTransactionauto extends Controller {

	public function index() {
		
	}
	
	public function check_finish_tranfer(){
		$this -> load -> model('transaction/customer');
		$check_finish_tranfer = $this -> model_transaction_customer-> check_finish_tranfer();
		foreach ($check_finish_tranfer as $value) {
			$this -> model_transaction_customer ->update_status_tranferlist_pdgd($value['id'],2,2);
			print_r($value['id']);echo "<br/>";
		}
			
	}

	public function time_finish_desposit(){
		$this -> load -> model('transaction/customer');
		$time_finish_desposit = $this -> model_transaction_customer-> check_time_finish_desposit();
		foreach ($time_finish_desposit as $value) {
			$this -> model_transaction_customer ->update_status_deposit($value['id'],3,3);
			print_r($value['id']);echo "<br/>";
		}
	}

}
