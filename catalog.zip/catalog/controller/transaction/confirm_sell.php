<?php
class ControllerTransactionSell extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/sell.js');
			
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		$data['url_submit'] = $this ->url->link('transaction/sell/submit');
		$data['getsell'] = array();
		$data['getsell'] = $this -> model_transaction_customer ->get_pd_create($this->request->get['token']);
		$data['getCustomer_wallet'] = $this -> model_transaction_customer ->getCustomer_wallet($this->session->data['customer_id']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/sell.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/sell.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	public function submit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$numbtc = array_key_exists('numbtc', $this -> request -> post) ? $this -> request -> post['numbtc'] : "Error";
			$amount = array_key_exists('amount', $this -> request -> post) ? $this -> request -> post['amount'] : "Error";
			$price = array_key_exists('price', $this -> request -> post) ? $this -> request -> post['price'] : "Error";
			$wallet = array_key_exists('wallet', $this -> request -> post) ? $this -> request -> post['wallet'] : "Error";
			if ($numbtc == "Error" || $amount == "Error" || $price == "Error" || $wallet == "Error" ) {
				$json['error'] = -1;
				
			}
			//buy
			$this -> load -> model('transaction/customer');
			
			$data['get_gd_create'] = $this -> model_transaction_customer -> get_pd_create($this->request->post['token']);
			
			count($data['get_gd_create']) == 0 && $this -> response -> redirect("/login.html");
			$data = array(	'pd_id' => $data['get_gd_create']['id'], 
							'gd_id' => 0,
							'pd_id_customer' => $data['get_gd_create']['customer_id'],
							'gd_id_customer' => $this->session->data['customer_id'],
							'price' => $price,
							'amount' => $amount,
							'numbtc' => $numbtc,
							'wallet' => $wallet);
			
			$create_tranfer = $this -> model_transaction_customer ->create_tranfer($data);
			$json['create_tranfer'] = $create_tranfer['transfer_code'];
			$json['url'] = $this->url-> link('transaction/sell/trade_sell&token='.$create_tranfer['transfer_code']);
			$this->response->setOutput(json_encode($json));
		}
	}

	public function trade_sell(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		$data['url_confirm_sell'] = $this -> url -> link('transaction/sell/update_status_tranferlist_pd&token='.$this->request->get['token']);
		$data['url_confirm_buy'] = $this -> url -> link('transaction/sell/update_status_tranferlist_gd&token='.$this->request->get['token']);
		$data['url_send'] = $this -> url -> link('transaction/sell/send&token='.$this->request->get['token']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/trade_sell.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/trade_sell.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	
	public function getCustomer_buyid($customer_id){
		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> getCustomer_buyid($customer_id);
	}
	public function get_pd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_pd_username($id_gd);
	}

	public function getCustomer_wallet($customer_id){

		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> getCustomer_wallet($customer_id);
	}

	public function update_status_tranferlist_pd(){

		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		$this -> model_transaction_customer -> update_status_pd($get_tranferlist['pd_id'],2);

		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function update_status_tranferlist_gd(){
		
		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
		$this -> response -> redirect($this -> url -> link('transaction/sell/trade_sell&token='.$this->request->get['token']));
	}
	public function send(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		// update coin
		
		//send bitcoi
		/*$block_io = new BlockIo(key, pin, block_version);
		$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
											'from_labels' => $label_send, 
											'to_labels' => $label_to));*/

	}

}
