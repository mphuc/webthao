<?php
class ControllerTransactionBuy extends Controller {

	public function index() {
		     // $block_io = new BlockIo(key, pin, block_version);
       //  $transactions = $block_io->get_balance();
       //  $amount = $transactions -> data-> available_balance;
       //  echo "<pre>"; print_r($amount); echo "</pre>"; die();

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/buy.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		$data['url_submit'] = $this ->url->link('transaction/buy/submit');
		$data['getCustomer_wallet'] = $this -> model_transaction_customer ->getCustomer_wallet($this->session->data['customer_id']);
		$data['getbuy'] = array();
		$data['getbuy'] = $this -> model_transaction_customer ->get_gd_create($this->request->get['token']);

		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/buy.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/buy.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	
	public function submit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$numbtc = array_key_exists('numbtc', $this -> request -> post) ? $this -> request -> post['numbtc'] : "Error";
			$amount = array_key_exists('amount', $this -> request -> post) ? $this -> request -> post['amount'] : "Error";
			$price = array_key_exists('price', $this -> request -> post) ? $this -> request -> post['price'] : "Error";
			$wallet = array_key_exists('wallet', $this -> request -> post) ? $this -> request -> post['wallet'] : "Error";
			if ($numbtc == "Error" || $amount == "Error" || $price == "Error" || $wallet == "Error" ) {
				$json['error'] = -1;
				
			}
			//buy
			$this -> load -> model('transaction/customer');
			
			$data['get_gd_create'] = $this -> model_transaction_customer -> get_gd_create($this->request->post['token']);
			
			count($data['get_gd_create']) == 0 && $this -> response -> redirect("/login.html");
			$data = array(	'pd_id' => 0, 
							'gd_id' => $data['get_gd_create']['id'],
							'pd_id_customer' => $this->session->data['customer_id'],
							'gd_id_customer' => $data['get_gd_create']['customer_id'],
							'price' => $price,
							'amount' => $amount,
							'numbtc' => $numbtc,
							'wallet' => $wallet);
			//print_r($data);die;
			$create_tranfer = $this -> model_transaction_customer ->create_tranfer($data);
			$json['create_tranfer'] = $create_tranfer['transfer_code'];
			$json['url'] = $this->url-> link('transaction/buy/trade_buy&token='.$create_tranfer['transfer_code']);
			$this->response->setOutput(json_encode($json));
		}
	}
	public function trade_sale(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		$data['url_confirm_sell'] = $this -> url -> link('transaction/buy/update_status_tranferlist_pd&token='.$this->request->get['token']);
		$data['url_confirm_buy'] = $this -> url -> link('transaction/buy/update_status_tranferlist_gd&token='.$this->request->get['token']);
		$data['url_send'] = $this -> url -> link('transaction/buy/send&token='.$this->request->get['token']);
		
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/trade_sale.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/trade_sale.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}
	public function trade_buy(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};
		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;
		$this -> load -> model('transaction/customer');
		$data['get_tranferlist'] = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		count($data['get_tranferlist']) == 0 && $this -> response -> redirect("/login.html");
		$data['url_confirm_sell'] = $this -> url -> link('transaction/buy/update_status_tranferlist_pd&token='.$this->request->get['token']);
		$data['url_confirm_buy'] = $this -> url -> link('transaction/buy/update_status_tranferlist_gd&token='.$this->request->get['token']);
		$data['url_send'] = $this -> url -> link('transaction/buy/send&token='.$this->request->get['token']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/transaction/trade_buy.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/transaction/trade_buy.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/account/login.tpl', $data));
		}
	}

	public function getCustomer_buyid($customer_id){
		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> getCustomer_buyid($customer_id);
	}
	public function get_gd_username($id_gd){

		$this -> load -> model('transaction/customer');

		return $this -> model_transaction_customer -> get_gd_username($id_gd);
	}

	public function getCustomer_wallet($customer_id){

		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> getCustomer_wallet($customer_id);
	}

	public function update_status_tranferlist_pd(){

		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_pd($this->request->get['token'],1);

		$this -> response -> redirect($this -> url -> link('transaction/buy/trade_buy&token='.$this->request->get['token']));
	}
	public function update_status_tranferlist_gd(){

		$this -> load -> model('transaction/customer');
		$this -> model_transaction_customer -> update_status_tranferlist_gd($this->request->get['token'],1);
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist($this->request->get['token']);
		$this -> model_transaction_customer -> update_status_gd($get_tranferlist['gd_id'],2);

		$this -> response -> redirect($this -> url -> link('transaction/buy/trade_buy&token='.$this->request->get['token']));
	}
	public function send(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] = $this;

		
		$this -> load -> model('transaction/customer');
		$get_tranferlist = $this -> model_transaction_customer -> get_tranferlist_buy($this->request->get['token']);
		count($get_tranferlist) == 0 && $this -> response -> redirect("/login.html");
		// update coin
		/*print_r($get_tranferlist); die;
		$amount_send = $get_tranferlist['amount_tf'];
		$this -> model_transaction_customer -> update_wallet_blockio($amount,customer_id)
		//send bitcoi
		$block_io = new BlockIo(key, pin, block_version);
		$block_io->withdraw_from_labels(array('amounts' => $amount_btc, 
											'from_labels' => $label_send, 
											'to_labels' => $label_to));*/
	}

}
