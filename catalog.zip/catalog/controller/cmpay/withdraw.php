<?php
class ControllerCmpayWithdraw extends Controller {

	public function index() {

		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/countdown/jquery.countdown.min.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit/countdown.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$data['self'] = $this;
		$data['price_sell'] = $this->config->get('price_sell');
		$data['price_buy'] = $this->config->get('price_buy');
		$data['url_submit'] = $this ->url->link('transaction/create/submit');
		$data['url_sell'] = $this ->url->link('transaction/tranfer/sell');
		$data['url_buy'] = $this ->url->link('transaction/tranfer/buy');
		$data['amount'] = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
		$data['get_question_transaction'] = $this-> model_transaction_customer -> get_question_transaction($this->session->data['customer_id'])['question'];
		$data['list_withdraw_register'] = $this -> model_transaction_customer -> list_withdraw_register();
		$data['get_bank_customer'] = array();
		$data['get_bank_customer'] =  $this -> model_transaction_customer -> get_bank_customer($this->session->data['customer_id']);
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/withdraw.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/withdraw.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/cmpay/account/login.tpl', $data));
		}
	}
	
	public function history_withdraw(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/countdown/jquery.countdown.min.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit/countdown.js');
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		$data['self'] =   $this; 
		$session_id = $this -> session -> data['customer_id'];
		$this -> load -> model('transaction/customer');
		$pages = isset($this -> request -> get['pages']) ? $this -> request -> get['pages'] : 1;
		$limit = 10;
		$starts = ($pages - 1) * 10;
		$sell_total = $this-> model_transaction_customer ->count_withdraw($this->session->data['customer_id']);
		$pagination_sell = new Pagination();
		$pagination_sell->total = $sell_total;
		$pagination_sell->page = $pages;
		$pagination_sell->limit = $limit; 
		$pagination_sell->num_links = 5;
		//$pagination->text = 'text';
		$pagination_sell->url = $this->url->link('cmpay/withdraw/history_withdraw', 'pages={page}', 'SSL');
		$data['withdraw'] = array();
		$data['withdraw'] = $this -> model_transaction_customer -> get_withdraw($this->session->data['customer_id'],$limit,$starts);
		
		$data['pagination_withdraw'] = $pagination_sell->render();	


		$paged = isset($this -> request -> get['paged']) ? $this -> request -> get['paged'] : 1;
		$starts = ($paged - 1) * 10;
		$sell_total = $this-> model_transaction_customer ->count_withdraw_confirm($this->session->data['customer_id']);
		$pagination_sell = new Pagination();
		$pagination_sell->total = $sell_total;
		$pagination_sell->page = $paged;
		$pagination_sell->limit = $limit; 
		$pagination_sell->num_links = 5;
		//$pagination->text = 'text';
		$pagination_sell->url = $this->url->link('transaction/deposit', 'paged={page}', 'SSL');
		$data['withdraw_confirm'] = array();
		$data['withdraw_confirm'] = $this -> model_transaction_customer -> get_withdraw_confirm($this->session->data['customer_id'],$limit,$starts);
		
		$data['pagination_withdraw_confirm'] = $pagination_sell->render();

		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/history_withdraw.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/history_withdraw.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/cmpay/account/login.tpl', $data));
		}
	}


	public function deposit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$amount_deposit = array_key_exists('amount_deposit', $this -> request -> post) ? $this -> request -> post['amount_deposit'] : "Error";
			$price_deposit = array_key_exists('price_deposit', $this -> request -> post) ? $this -> request -> post['price_deposit'] : "Error";
			$bank_name = array_key_exists('bank_name', $this -> request -> post) ? $this -> request -> post['bank_name'] : "Error";
			$password_transaction = array_key_exists('password_transaction', $this -> request -> post) ? $this -> request -> post['password_transaction'] : "Error";
			$user_deposit = array_key_exists('user_deposit', $this -> request -> post) ? $this -> request -> post['user_deposit'] : "Error";
			$amount_deposit = doubleval(str_replace(",","",$amount_deposit));
			$price_deposit = doubleval(str_replace(",","",$price_deposit));
			if ($amount_deposit == "Error" || $price_deposit == "Error" || $bank_name == "Error" || $password_transaction == "Error" || $user_deposit == "Error" ) {
				$json['error'] = -1;
				$this->response->setOutput(json_encode($json));
			}
			else
			{
				$this -> load -> model('transaction/customer');
				$check_password_transaction = $this -> model_transaction_customer -> check_password_transaction($this->session->data['customer_id'],$password_transaction);
				if ($check_password_transaction > 0)
				{
					
					$check_deposit_customer = $this -> model_transaction_customer ->check_deposit_customer($this->session->data['customer_id']);
					if ($check_deposit_customer > 0){
						$deposit_result['limit'] = $check_deposit_customer;
					}
					else
					{
						$deposit = $this -> model_transaction_customer -> insert_deposit($this->session->data['customer_id'],$amount_deposit,$price_deposit,$bank_name,$user_deposit);
						if ($user_deposit == 0)
						{
							// admin
							$get_bank_deposit = $this -> model_transaction_customer -> get_bank_deposit($bank_name);
							$this -> model_transaction_customer -> update_deposit($get_bank_deposit['account_holder'],$get_bank_deposit['account_number'],$get_bank_deposit['branch_bank'],$deposit['id']);
							$deposit_result['success'] = array_merge($get_bank_deposit, array('id_deposit' => $deposit['id'],'code_deposit' => $deposit['deposit_code'], 'price_deposit' => $price_deposit));
						}
						else
						{
							// user
							// get bank user
							$get_user_by_username = $this -> model_transaction_customer -> get_bank_customer_buy_bankname($user_deposit,$bank_name);
							$this -> model_transaction_customer -> update_deposit($get_user_by_username['account_holder'],$get_user_by_username['account_number'],$get_user_by_username['branch_bank'],$deposit['id']);
							// send mail


							$deposit_result['success'] = array_merge($get_user_by_username, array('id_deposit' => $deposit['id'],'code_deposit' => $deposit['deposit_code'], 'price_deposit' => $price_deposit));
						}
					}
				}
				else
				{
					$deposit_result['password'] = -1;
				}
				$this->response->setOutput(json_encode($deposit_result));
			}
		}
	}

	public function show_bill_withdraw(){
		$deposit_code = $this -> request->post['deposit_code'];
		$this -> load -> model('transaction/customer');
		$deposit_result['success'] = $this -> model_transaction_customer -> get_bill_withdraw($deposit_code);
		$this->response->setOutput(json_encode($deposit_result));
	}
	public function get_username($customer_id){
		$this -> load -> model('transaction/customer');
		
		return $this -> model_transaction_customer -> get_username($customer_id);
	}
	public function withdraw(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$bank_name = array_key_exists('bank_name', $this -> request -> post) ? $this -> request -> post['bank_name'] : "Error";
			$account_number = array_key_exists('account_number', $this -> request -> post) ? $this -> request -> post['account_number'] : "Error";
			$account_holder = array_key_exists('account_holder', $this -> request -> post) ? $this -> request -> post['account_holder'] : "Error";
			$branch_bank = array_key_exists('branch_bank', $this -> request -> post) ? $this -> request -> post['branch_bank'] : "Error";
			$amount_withdraw = array_key_exists('amount_withdraw', $this -> request -> post) ? $this -> request -> post['amount_withdraw'] : "Error";
			$price_withdraw = array_key_exists('price_withdraw', $this -> request -> post) ? $this -> request -> post['price_withdraw'] : "Error";
			$password_transaction = array_key_exists('password_transaction', $this -> request -> post) ? $this -> request -> post['password_transaction'] : "Error";
			$user_withdraw = array_key_exists('user_withdraw', $this -> request -> post) ? $this -> request -> post['user_withdraw'] : "Error";
			$amount_withdraw = doubleval(str_replace(",","",$amount_withdraw));
			$price_withdraw = doubleval(str_replace(",","",$price_withdraw));
			
			if ($bank_name == "Error" || $account_number == "Error" || $account_holder == "Error" || $amount_withdraw == "Error" || $price_withdraw == "Error" || $password_transaction == "Error" || $user_withdraw == "Error" || $branch_bank == "Error" ) {
				$json['error'] = -1;
				$this->response->setOutput(json_encode($json));
			}
			else{
				$this -> load -> model('transaction/customer');
				$check_password_transaction = $this -> model_transaction_customer -> check_password_transaction($this->session->data['customer_id'],$password_transaction);
				if ($check_password_transaction > 0)
				{
					$check_withdraw_customer = $this -> model_transaction_customer ->check_withdraw_customer($this->session->data['customer_id']);	
					if ($check_withdraw_customer > 5){
						$json['limit'] = $check_withdraw_customer;
					}
					else
					{
						$data['amount'] = $this -> model_transaction_customer -> get_wallet_coinmax()['amount'];
						if ($data['amount'] >= $amount_withdraw){
							
								$insert_withdraw = $this -> model_transaction_customer -> insert_withdraw($this->session->data['customer_id'],$bank_name,$account_holder,$account_number,$amount_withdraw,$price_withdraw,$user_withdraw,$branch_bank);
								$this-> model_transaction_customer -> update_coinmax($this->session->data['customer_id'],$amount_withdraw,$add=false);
							if ($user_withdraw == 0)
							{

							}
							else
							{
								// send mail
							}
							
							$json['success'] = 1;
						}
						else
						{
							$this -> response -> redirect("index.php?route=cmpay/withdraw/#money_no");
						}
					}
				}
				else
				{
					$json['password'] = -1;
					
				}
			}
			$this->response->setOutput(json_encode($json));
		}
	}
	public function get_bank_customer(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$this -> load -> model('transaction/customer');
			$customer_id = $this -> request -> post['customer_id'];
			$get_bank_customer =  $this -> model_transaction_customer -> get_bank_customer($customer_id);
			$this->response->setOutput(json_encode($get_bank_customer));
			
		}
	}

	public function confirm_deposit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		$filename = html_entity_decode($this->request->files['avatar']['name'], ENT_QUOTES, 'UTF-8');

		$filename = str_replace(' ', '_', $filename);
		if(!$filename || !$this->request->files){
			die();
		}

		$file = $this -> request -> post['token'].'_'.$filename . '.' . md5(mt_rand()) ;


		move_uploaded_file($this->request->files['avatar']['tmp_name'], DIR_UPLOAD . $file);
		$server = $this -> request -> server['HTTPS'] ? $this -> config -> get('config_ssl') :  $this -> config -> get('config_url');
		$linkImage = $server . 'system/upload/'.$file;
		$this -> model_transaction_customer -> update_images_deposit($this->request->post['deposit_code'],$linkImage);
		$this -> response -> redirect("index.php?route=transaction/deposit");
	}
	public function confirm_withdraw(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language

		$this -> load -> model('transaction/customer');
		$filename = html_entity_decode($this->request->files['avatar']['name'], ENT_QUOTES, 'UTF-8');

		$filename = str_replace(' ', '_', $filename);
		if(!$filename || !$this->request->files){
			die();
		}

		$file = $this -> request -> post['token'].'_'.$filename . '.' . md5(mt_rand()) ;


		move_uploaded_file($this->request->files['avatar']['tmp_name'], DIR_UPLOAD . $file);
		$server = $this -> request -> server['HTTPS'] ? $this -> config -> get('config_ssl') :  $this -> config -> get('config_url');
		$linkImage = $server . 'system/upload/'.$file;

		$this -> model_transaction_customer -> update_images_withdraw($this->request->post['withdraw_code'],$linkImage);
		$this -> response -> redirect("index.php?route=cmpay/withdraw/history_withdraw");
	}
	public function complete_deposit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		$get_deposit_buy_code = $this -> model_transaction_customer -> get_deposit_buy_code($this->request->get['token']);
		count($get_deposit_buy_code) == 0 && $this -> response -> redirect("/login.html");
		if ($this->get_blance_coinmax($get_deposit_buy_code['user_deposit']) >= $get_deposit_buy_code['amount']){
			$this -> model_transaction_customer -> update_gd_deposit($this->request->get['token'],1);
			$this-> model_transaction_customer -> update_coinmax($get_deposit_buy_code['user_deposit'],$get_deposit_buy_code['amount'],$add=false);
			$this-> model_transaction_customer -> update_coinmax($get_deposit_buy_code['customer_id'],$get_deposit_buy_code['amount'],$add=true);
			
			

			$this -> model_transaction_customer -> saveTranstionHistory($get_deposit_buy_code['user_deposit'],0,$get_deposit_buy_code['amount'],$this->get_blance_coinmax($get_deposit_buy_code['user_deposit']), "Send to ".$this->getid_customer($get_deposit_buy_code['customer_id'])." ".number_format($get_deposit_buy_code['amount'])." VNĐ from Deposit VNĐ", 0);

			$this -> model_transaction_customer -> saveTranstionHistory($get_deposit_buy_code['customer_id'],$get_deposit_buy_code['amount'],0,$this->get_blance_coinmax($get_deposit_buy_code['customer_id']),"Receive ".number_format($get_deposit_buy_code['amount'])." VNĐ from ".$this->getid_customer($get_deposit_buy_code['user_deposit'])." from Deposit VNĐ", 0);
			$this -> response -> redirect("index.php?route=transaction/deposit");
		}
		else
		{
			$this -> response -> redirect("index.php?route=transaction/deposit/#money_no");
		}	
	}
	public function report_deposit(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		$get_deposit_buy_code = $this -> model_transaction_customer -> get_deposit_buy_code($this->request->get['token']);
		count($get_deposit_buy_code) == 0 && $this -> response -> redirect("/login.html");
		$this -> model_transaction_customer -> update_gd_deposit($this->request->get['token'],2);
		$this -> response -> redirect("index.php?route=transaction/deposit");
	}
	public function complete_withdraw(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		$get_deposit_buy_code = $this -> model_transaction_customer -> get_withdraw_buy_code($this->request->get['token']);
		count($get_deposit_buy_code) == 0 && $this -> response -> redirect("/login.html");
		//if ($this->get_blance_coinmax($get_deposit_buy_code['customer_id']) >= $get_deposit_buy_code['amount']){
		$this -> model_transaction_customer -> update_gd_withdraw($this->request->get['token'],1);
		$this-> model_transaction_customer -> update_coinmax($get_deposit_buy_code['user_withdraw'],$get_deposit_buy_code['amount'],$add=true);
		/*$this-> model_transaction_customer -> update_coinmax($get_deposit_buy_code['customer_id'],$get_deposit_buy_code['amount'],$add=false);*/
		$this -> model_transaction_customer -> saveTranstionHistory($get_deposit_buy_code['customer_id'],0,$get_deposit_buy_code['amount'],$this->get_blance_coinmax($get_deposit_buy_code['customer_id']), "Send to ".$this->getid_customer($get_deposit_buy_code['user_withdraw'])." ".number_format($get_deposit_buy_code['amount'])." VNĐ from Deposit VNĐ", 0);

		$this -> model_transaction_customer -> saveTranstionHistory($get_deposit_buy_code['user_withdraw'],$get_deposit_buy_code['amount'],0,$this->get_blance_coinmax($get_deposit_buy_code['user_withdraw']),"Receive ".number_format($get_deposit_buy_code['amount'])." VNĐ from ".$this->getid_customer($get_deposit_buy_code['customer_id'])." from Deposit VNĐ", 0);
		$this -> response -> redirect("index.php?route=cmpay/withdraw/history_withdraw");
		/*}
		else
		{
			$this -> response -> redirect("index.php?route=transaction/deposit/#money_no");
		}	*/
	}
	public function report_withdraw(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		
		$session_id = $this -> session -> data['customer_id'];

		//language
		$this -> load -> model('transaction/customer');
		$get_deposit_buy_code = $this -> model_transaction_customer -> get_withdraw_buy_code($this->request->get['token']);
		count($get_deposit_buy_code) == 0 && $this -> response -> redirect("/login.html");
		
		$this -> model_transaction_customer -> update_gd_withdraw($this->request->get['token'],2);
		$this -> response -> redirect("index.php?route=cmpay/withdraw/history_withdraw");
	}
	public function get_blance_coinmax($customer_id){
		$this -> load-> model('transaction/customer');
		$get_blance_coinmax = $this -> model_transaction_customer -> get_wallet_coinmax_buy_customer_id($customer_id);
		return $get_blance_coinmax['amount'];
	}
	public function getid_customer($customer_id){
		$this -> load-> model('transaction/customer');
		$get_username_all = $this -> model_transaction_customer -> get_username_all($customer_id);
		return "ID".substr($get_username_all['customer_code'],0,6);
	}
	public function get_bank_customer_chose(){
		function myCheckLoign($self) {
			return $self -> customer -> isLogged() ? true : false;
		};

		function myConfig($self) {
			$self -> document -> addScript('catalog/view/javascript/transaction/deposit.js');
			
		};

		!call_user_func_array("myCheckLoign", array($this)) && $this -> response -> redirect("/login.html");
		call_user_func_array("myConfig", array($this));
		if ($this -> request -> post){
			$this -> load -> model('transaction/customer');
			$bank_name = $this -> request -> post['bank_name'];
			$get_bank_customer =  $this -> model_transaction_customer -> get_bank_customer_buy_bankname($this->session->data['customer_id'],$bank_name);
			$this->response->setOutput(json_encode($get_bank_customer));
		}
	}
}
