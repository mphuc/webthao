<?php
class ControllerCmpayPage extends Controller {
	public function index() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/cmpay.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/cmpay.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/cmpay/cmpay.tpl', $data));
		}
	}
	public function about() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/p_about.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/p_about.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/cmpay/p_about.tpl', $data));
		}
	}
	public function register() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/p_rules.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/p_rules.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/cmpay/p_register.tpl', $data));
		}
	}
	public function how() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/p_how.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/p_how.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/cmpay/p_how.tpl', $data));
		}
	}
	public function read() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/p_read.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/p_read.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/cmpay/p_read.tpl', $data));
		}
	}
	public function faq() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/p_faq.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/p_faq.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/cmpay/p_faq.tpl', $data));
		}
	}
	public function get() {

		$data['base'] = HTTPS_SERVER;
		$data['self'] = $this;
		if (file_exists(DIR_TEMPLATE . $this -> config -> get('config_template') . '/template/cmpay/p_get.tpl')) {
			$this -> response -> setOutput($this -> load -> view($this -> config -> get('config_template') . '/template/cmpay/p_get.tpl', $data));
		} else {
			$this -> response -> setOutput($this -> load -> view('default/template/cmpay/p_get.tpl', $data));
		}
	}
	
}