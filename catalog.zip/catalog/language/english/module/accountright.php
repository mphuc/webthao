<?php
// Heading
$_['heading_title']    = 'Account right';

// Text
