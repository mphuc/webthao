<?php
// Heading
$_['heading_title']    = 'Account left';


// Text
$_['title_account']    = 'Your account';

//menu top
$_['dashboard']    = 'Dashboard';
$_['registerUser']    = 'Register User';
$_['token']    = 'Token';
$_['provideDonation']    = 'Investment (PD)';
$_['getDonation']    = 'Get Donation (GD)';
$_['downlineTree']    = 'Downline Tree';
$_['transactionHistory']    = 'Transaction History';
$_['introduct']    = 'Introduct';
$_['profileSetting']    = 'Profile Setting';
$_['logout']    = 'Logout';
$_['refferal']    = 'Refferal(S)';