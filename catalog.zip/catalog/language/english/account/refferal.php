<?php
// Heading
$_['heading_title']     = 'Referral(S)';
// Text
$_['text_home']            = 'Home';
$_['text_register_user']            = 'List of Refferal(S)';
$_['text_button_create']            = 'Register New Member';
$_['NO']            = 'NO';
$_['Account']            = 'Account';
$_['USERNAME']            = 'USERNAME';
$_['LEVEL']            = 'LEVEL';
$_['DOWNLINE']            = 'DOWNLINE TREE STATISTICS';
$_['EMAIL']            = 'EMAIL';
$_['DATE']            = 'DATE CREATED';
$_['WALLET']            = 'WALLET';
$_['TELEPHONE']            = 'PHONE NUMBER';
$_['EMAIL']            = 'EMAIL';
$_['COUNTRY']            = 'COUNTRY';