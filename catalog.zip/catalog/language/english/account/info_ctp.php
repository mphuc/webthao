<?php
// Heading
$_['heading_title']  = 'Cộng tác phí dự kiến';

// Text

// Entry

// Error
?>