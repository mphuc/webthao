<?php
// Heading
$_['heading_title']  = 'Binary system';

// Text

// Entry

// Error
?>