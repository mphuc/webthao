<?php
// Heading
$_['heading_title']  = 'Statistic';

// Text
$_['text_username']  = 'Name';
$_['text_email']  = 'Email';
$_['text_phone']  = 'Phone';
$_['text_date']  = 'Register date';
$_['text_package']  = 'Package';
$_['text_month_invest']  = 'Month invest';
$_['text_money_invest']  = 'Money invest';

// Entry

// Error
?>