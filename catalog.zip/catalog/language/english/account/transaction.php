<?php
// Heading
$_['heading_title']      = 'Transaction History';
$_['text_breadcrumb']      = 'Home';
// Column
$_['column_no']  = 'No.';
$_['column_date_added']  = 'Date';
$_['column_description'] = 'Detail';
$_['column_amount']      = 'Amount';
$_['column_type']      = 'Type';

$_['column_wallet']      = 'Item';

// Text
$_['text_account']       = 'Account';
$_['text_transaction']   = 'Your Transactions';
$_['text_total']         = 'Your current balance is:';
$_['text_empty']         = 'You do not have any transactions!';