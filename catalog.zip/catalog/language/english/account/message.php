<?php
// Heading
$_['heading_title']  = 'Message';

// Text

// Entry

// Error
?>