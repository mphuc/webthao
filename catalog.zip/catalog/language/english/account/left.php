<?php

$_['dashboard'] = 'Dashboard';
$_['Register'] = 'Register User';
$_['provideDonation']    = 'Deposit';
$_['getDonation']    = 'Withdrawals';
$_['downlineTree']    = 'Downline Tree';
$_['Refferal(S)']    = 'My Refferal(S)';
$_['Transaction']    = 'Transaction History';
$_['pin']    = 'Pin';
$_['proFile']    = 'Account Setting ';
$_['proFiles']    = 'Account ';
$_['logout'] = 'Logout';

$_['text_account']       = 'Update information';
$_['text_password']      = 'Login Password';
$_['text_transaction_password']   = 'Transaction Password';
$_['text_bank']       = 'Bank Address';
$_['text_username']       = 'Username';
$_['text_level']       = 'Level';
$_['text_email']       = 'Email address';
$_['text_phone']       = 'Phone number';

$_['text_old_password']       = 'Old Password';
$_['text_new_password']       = 'New Password';
$_['text_confirm_password']       = 'Confirm New Password';
$_['text_button_password']       = 'Change Password';

$_['text_wallet']       = 'Wallet Address BTC';