<?php
// Heading
$_['heading_title']  = 'Downline Tree';
$_['text_home']            = 'Home';
$_['text_binary']            = 'Downline Binary';
$_['text_binary_tree']            = 'Downline Tree';
$_['top'] = 'Back to top';
// Text

// Entry

// Error
?>