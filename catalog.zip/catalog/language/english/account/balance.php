<?php
// Heading
$_['heading_title']  = 'Balance history';

// Text
$_['text_datetime']  = 'Date+ Time';
$_['text_amount']  = 'Amount';
$_['text_description']  = 'Description';
$_['text_fromuser']  = 'From user';

$_['text_total_profit']          = 'Total profit';
$_['text_total_commission']          = 'Total commission';
$_['text_total_gift']          = 'Total gift';
$_['text_total_payout']          = 'Total payout';
$_['text_total_balance']          = 'Total balance';
$_['text_money_invest']          = 'Money invest';
$_['entry_type_contract']          = 'Type contract';
$_['entry_month_invest']          = 'Month invest';
$_['entry_date_add']          = 'Date add';
// Entry

// Error
?>