<?php
// Heading
$_['heading_title'] 	= 'Frequently Asked Questions';
 
// Text
$_['text_question'] 	= 'Question';
$_['text_answer'] 	    = 'Answer';
$_['text_error'] 		= 'The page you are looking for cannot be found.';